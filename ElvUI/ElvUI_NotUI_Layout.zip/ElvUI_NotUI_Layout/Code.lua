--Don't worry about this
local addon, ns = ...
local Version = GetAddOnMetadata(addon, "Version")

--Cache Lua / WoW API
local format = string.format
local GetCVarBool = GetCVarBool
local ReloadUI = ReloadUI
local StopMusic = StopMusic

-- These are things we do not cache
-- GLOBALS: PluginInstallStepComplete, PluginInstallFrame

--Change this line and use a unique name for your plugin.
local MyPluginName = "NotUI Layout"

--Create references to ElvUI internals
local E, L, V, P, G = unpack(ElvUI)

--Create reference to LibElvUIPlugin
local EP = LibStub("LibElvUIPlugin-1.0")

--Create a new ElvUI module so ElvUI can handle initialization when ready
local mod = E:NewModule(MyPluginName, "AceHook-3.0", "AceEvent-3.0", "AceTimer-3.0");

local function DetailsImportString()
	StaticPopupDialogs["detailsInstall"] = {
				text = "This is your import string for Details!:",
				button1 = "Thanks!",
				OnShow = function (self, data)
					self.editBox:SetText("T3x3Yroow69S4WxS9eXwYeeGaKEdFHuvsvRTvLQwLQ6Eh7kuwuzsjLrLkP2mtvQ14Due23778dI9nocFHFhM9nYFFaGKGmjLYQ7P7z2n65NsszIFp4GZ578daUqCX5xm(UvLxnFrb)113u(WK8vflZNSQCrXK5tlxEXLxmEA(DBUFvXKvf5ly5UH)8au(7kwSyA(6n8pUD(6PZY3KZFp)(v2FwSSy11pYFBw(T5xxGFBZfJxHE5Q8zO9xIwBK4IX4xgfFXOO9I53F3I8hlwnzwXM85lwp5H5lNv(GD8nnhduwH1Fgvz8Hl(Yho(IXxMVAYMIFKdXlgp(ZpUy(Yc2o5lwmX1wR5SAY1RkV)ooFUFnMlCQUC(T5BMxUCnhIRkURC1MjCYnbnXNxZIUQ42YV4M53o5QvL3ozz(TfU5lQ993obF9k2ttlV9Y8nt2m)woeJavBr(61wA46jRVff5IXhVCtXQRYNw8X9Nn70LR)4BCZXpoNuN1F0wLI6I7hrBkN8WnLxm(p9)8p9)5p9)6F5)2)Y)9)0)7)L)h)P)V)P)FxmUQ3VAr(1OB1SBla94(L2zBXmou58fJTnlk4hUC2K1fRq9MCx(k8BCAoR4Q87xSzYLxJ5XIYvCTiktbk9dLRwmRAYnF9KnRYxFdRYDF5Uj5R9ev0jxww(5BZx9z7sXK1Z)dKmGgOMipbSlfZMa6gAJVuSG9Hk5IX4VM(5jZ3uC7Kff8ZrJzzpSLNLsKWry(MBaPOCXM53HVc9ehfoMJ1pl)08LR3KVCkOR3wS8(jtxmh9hiQL3vyzVRxbTuULfpm9g8NflT8RwI36Ifx5jmKybUCBHxE)DtwuED59B4h30nZMVo)YfKMVAYnZV(Mf4)BlIL4HgA508nyx2Mc7Ul2UtU8r)oVnf53A3d1MUDXiPSIkG(0nAwZDfZkU8(RUcli3V6oS9y8vRMxSC2IhVAo3pmdeQYv5CY423o(6vfyEJUTCbiD43Ee7IXgSQ9OGTBgjBC2GAdUfUzJZB)0ArjOFEgSjxE)MnCde((BXELvpozfg)J0k7GDghQlMF78noMZgA06IRXQXM12wZXMw1(U1uhNLTHVd7FV8YvfFzULGasHFr4YvLFUWT5)IXTA97V7UvfRRyxhfvVzIchw74mlVZU3VpbmB6HVn)hR4Br3ZT5t284DfKrB8Y7VTy1Cu5jRFCnzKx)4TxwUynLeUb7CVQC5MjCFVDbJCH4Ro(8x)0N2)l5l380NElOZf4hLBUz(0N(07kMn)(BTYkDJ61tVP42ClVD7ncpmF2gm)KjygwtsZVf7YbfxffqtCBnq3pzYDL2XXYYv36eO)4fh9Q00ytsMwKOsfX4xV4QxPWI4pEXrADCSYOsZmXzsHkJFdibpCXrMeLklltNeLeNisv8BWE1BW3ePLImPsfPstKgT7Bixf4BDDjjC)ODk9aMarrSEJIXp3WYDZC7g6AXQwsTGI3WU3n3aEJRVPALJ7SMdPBC)g1HT0XnI96yMFd20AN6JEvIYkwqKHHbAE(hONGmVvwoKRUFXIllXcXkV4RO9s8deSfFs5v(btWMwpZVR9fUwN8h8FvEgjUuXrg1emXQQ9f1dewL1tIPYMPRkPCfQplCpdLorESj5qiZYj3cH4ZNq2T1BwnF51wfBtM8aeutPDU6eopROwTiR(U327wLGy348Lxv(CyeWMKP74SZwu3uZZcoM7GpHuzRU7dCFWzvFGxF4bDkx3pgJjk(y69R3a90wHcyGD18Fe7ETkLCsW7BXImM3HrmNHRSsRjdXIIRC)YLfBEGcn9lOoSgq8(0p7vO601xRHaB5WM28RaDWrGoiqgGNkDexK(4rND8)5)HZNmzVZp)iQ2BQvIJLvH8GGP7Q1fyq8kIOWnndNFJ)Vs5GI)4Ep9j7Vj)J2Fe)hblt5SIf295qwigh2)g4JiMT1FC)PZNDWkROe89fRElvkS37aRguf0u6FGA))4H)JVF)rJp(0rrXF8nNE6B2)nJ)4RH2J8vRY)4Rp9K3S)zNT)jN(6pmEVBJR6V8f3DtUFpKRnDRpZibY9b1fruvPMISXtX8ajKeM30ppBv5DCkn8kzZ2UkeHEUVN(0b5RoWY2)0NIj206rJVpIQQ2juTXY1lMVPMl6MchxrSQz9FaUDlQuqFwv8rkhp)JN7k)A8NlwmhIK3A1fRTy2pfcVBe01dRElg4iheh70oQzAtWmqgr7IUNXJhY4ko)PIvBJFdDiJxZ2p7xzX0BBNdyJCaBb7YZxH8So4AT186vqsMvFliVDeOmaV)zqHpycWNn(BQ(K(303s8HD3xTuaUYTd0rh53sbG29lDWKRRVT3iKdplSOQl7BZ5tF6F2V9K7lR5l9CdBlnP1xDsOSL1vWv5k82m4V5Vz(0na3qNzBOCQDBI3Pw)uz09KKoJ)EeTVlJRLL16ASSiEUJ21jy83a8oyKFKfB86Jag1Ip(HJFL)Vpz(6nV6BBQqTS6DbLwdxr4eTYYHADDoZAwVzcqZE)DZi4)MnAfWEM8nGemE0PJoSlJ2wla25zfINT5dgxGTtZ38i2C)W8ntHc98LwRLUBX9xdaHeAn2yd7dM6Wtl8WLCd0oB2pGRb4Fs4)OD66jPz0RIP0JChcSnez66CmsWmBM1sllkS2axQGD5TBBItaWrPgPolnolZKfNKMMc0IjYkmG(f9kmrUMqyXTDTv0zZqVrJswSTax6uF71Ce4LGYfZN1wnY2SDr14qljo0L2n1vOOduFmFj2rU2kh7l5lU3QkH1fT3owq5Uwq1UwWKDTG6DTGMDTGP7AbZ21cc5)7Aj351gXoV4i25vhXoV8i211hVWipAEldSSYQgy1xlMFlmMJsfrALjtiuWISK4Q9s0i(a9wohO9o6dly5W6nZN6fRgSj2IEUK(ga9D449aNp3Ew40ViGBRhgwvqXtoZOA2z7LAr3v4072Leextcmr1fN6ricI1EG3pm)UI(QSZFeTrxaBNGAmyJpeGtD(CxFLqhyMT1A5j5xohqcNt3hi5Fd7PU1)xbEzQA2020ZyJF6JsoEdOWRbA0X5FbutcNTGI2He8dpF)Jpz8KXNV)5Fy8b7F2K3FYhE7XJM8AGU(7Qmnz4I9(38(X1(1Gn8ZxYZR9zW5vEYGeOJSk(2FkmraFv(IN(07HsD(htF0vI9PXM1(b58qiRJRWsB)Rx)I40F2PZ4dF77oC05)ShOIFHhOULNFUJY4)Smk34TBDhiRB6zVtTlxSWY3G9nGFUyIx3xOiaVQ)dQCMIFexzXgDfDlWW0X5)rV9gCEUY5gHkuq7oERWwyXdawHfts9h6CEAWMpPBVNDx6WMlmzhSPmONV8AxWmcqy1M2r55voRSRiivT8Ri6EgV7CQDALfetB9dLlxuaPfoVBBfwbjWRRadJjtjN2LlDcsCJwG)X1uhzIJsmAHiwymzgOKe6esA5ISjwxb7N8A7S)vYG5NZ3WR8EdclC5B7PSw(qA(shPad8hzTMmz9YCkiLKuRF3SUTYcVYcw8CpF7bvI5USh3awHVR74QnPhKAA064to9hqJo)Ygh8(iOf6yLmwfNMiJLPQiV(XF8IJELrMgzm4BW)MeN5DA547kNVedLdo98Zp9DND8B)2ApfpaWvNZZHmERp88ooRzO7nGRxCNB8bilKcx5Johj873EnyhSEIa(DUURYT22Xe(JlgFuo2(gO1ytnRE9SG9jmy)sIeEtPniATus3M(h4GXDyOz5dME)kimyJtUc7zSUxXH3IVcte7hYVCYA6B822X0MHXA0t565tZl)REpE7wE)wp6QEns7biN(U87kifTdB0asSc9cNlwbhPYmPjzIuJWKLehP8tBixAAjw0ATyjcnhApJlUiwjx1yw8Eg7O0O4KO40uHjvP9BE0CpTnKjTD4wTDyVKJJcCkI1t6q9jJQ22chFKR51XI0AZyqJF8RpD04pE8OVFceEoFXKZXmGC(Va(0AtSR8(hvQzxBSW19qKPz(B739l32c9o(KlUogLoFYf7PYP2o3z84xDSAsvkSkivjQSiUseW5Qs1Y4utQwJVZkQ63IvZ)2ownB5f0)IgKMED08)gk6mdfFIbu7vh0HEfm2Fql2oOi)R)O88vfuR)sfDMNlaJ)AfOMEJq0VMbPzWaU0RVU3owjdf64)8eBMFUX84Nqij(5eYN(JlYabcAhc5ZFoc7XFMd9Z2HUQjAz7A0CE5ad(NNy10j8I)x2Py18p)lwGAEbxA(BbR53cwZVfSM)AmynVGl1IRlZoeYMTS0miRNF6twH5qeYMhPiN)1ASBgkWl7sqBE(aJ9BHU53cDZVf6MGq3eeHKlho6n7quq(1mSoDIO0xzCDAfTQ)Yf6M6GY0kynTdJtqaE6g6gfaCzWpnzAHXh6ME9jENy8)ZnqnIkpvSviG(jfvMDkEpFnrRrlsfISeT2Kibwu(vI)ceTMwrB6NtmAgYR))vuOygiYu)IgmM)I4s7Njt5cItZWXJ5OSOigGfzwuIWeRsC8AOth6BKd(nkFaCvsvusKeePSAo3wb4ncZ2iPjnRABsveF0mspXjG6MaGM6EJ4Zr6mbJ6PmIb2kZsNtSsypkrQXUMi2XylO2oUu2rCIovMOItYIr10a8D9iwNgLPuXQSmGQnwAAgXde)imefCRCscMlGfWVy(Zl(ruI46pwS4l3p)VAcG0xDOy)LjatB6EW3U7l2PE3ZYKLNhlc0ZJw3J0L4zDaZoaBW6BTqcH9dApKf(HSpUJ7j8dzzJRVD4w85jBO3WB7lOJwn)p80N(hUpFgLo)0No)CEY44z3SbkeOEwPCHcWRD)qNbMUAKPRgAA)ytzdlAdqGQPOvMI)8zfNevtcEo3avDK0QgPofm9KRECPB1C3HKCXI5ZCoXQ6qPnbCNq8vUBJZwNVXllxBl)wFXMYvxFt9551D(wBDUwt6wPMJ)iQE1j3ZUGCEdLqKKwtjKUJzX0fL3pBI)Gf3CaHbySpxaZZqF8iqhctxP6TPaF7IQJbzJ)OMUi)2kGkVknqJwSJT5vWeF2v3WHpuywC7LoB2cyEFm0l))ylx(JAypRV0Z1yKuFWeR8FM7WnA3zadjPSkRtWTdwxy6k5FFZ8IfZ85XGZNJqKR1cVV9dJo)WZARrEprCsfdg)nlhwSv11pS)zND8PdwEFzfUcF2PV9dh2ija6fu6uOv1vjPreLjn9wZ3T)BBQOT1J70eBxN3F45VCv2Z2HkhguAKZzF443uxTMHKTUQmLaQA6FY9Uth9DnZT6jfuGfuL9QjFSvTgvT)5F73nYIiSNb7qvdD24NBzQZSA83U)72F0oqn6U8(HrF3iiaA7P1q0V3F2Xho(8DCnUNU7TND6hE)7pz)FFZKBh619H0g6RKb73O4m8xQ0(R(HJo8D)(DLw(MdbXV9UKQvzPVUdTQ9TeH6oYCTfHD)t2)nhpAWrz3(6WV)0VlyesiAUg3wVb4HXUzVNh2PHyNLVn13BdtwdRgTzjsWjOgYNR9IFtExCt5MPLRwYdmD5DwBVo3br3hiwl4O2h064Tph0a(X1W2UQZcDYwN7yE06xBnLvfvDDeadwUdg7Bvszpd8wlnCxUcwr81nb)COGzTZLev6dDN18IzZTQMUCvz(mEVt0oCZwnwwtxbGo3P8)bRS)YzL2wBv(S53Zd)ToQEIxvR3dk4rjczKijtW0KegxAAakdyf0CLnopNX)UkmSTUGbQo51m5kZ)XH0hQsAqgGDpo9HbXJAlDd7PRIlCQ0ZqO6tNWEM0kUUkeuk52sLQ4Xu(YKA2sWVQcjw1(4mRU09p7Wr7p53F4jNulQkeT3ZlCrv1VvdTUAbe1m)(seP6kUVvNLKnKCDJPExB1at2m(F7zhE4Oodlr4GA8HNCu93dZPGbxEXIXIKkaGUpVJU2QPqwvPuI(eUVfY8UYZ3YN8Dekz7aNeWkregzFYvsQ4isQMHMSTeeJvxWZh6tG9WCt3GDVpjX6Q1trwRwU27zyh3Od)W5NT)j9XQ0JKZ461)kUoyuRQladzh2iV8qRnC8sjbyNDMhvjnSDOkCx3jlFei1SrEOy9AAQyWfyXMBwvalewmR2bG2DWb3Dd(ZkCTuR7GqYP2SPXN(Xf53A94YYRMBJ(YvoHvUyjB7R)P7P8PzfB8EwWExZaSNUSOyA(0BST1sMTyqABRj0TeB80jZUF51fUQAtTSAb15tNAVgv205(rHi1Dxqk83cUHuQVrEgSeo5tCSfGGDKooa5Gilrk6barhvxJekTPH9SRwY9QkS2vATmqfzshT(DBAAM1Uapgfu8mya7w24NbFu7YI5wAZgK6sBgyYfN0m7Qqqj6FmO2v7eqztEo8TDlUw)vGggn(ZT2TDPdOgY4uX2uKTRs2ZnEQrQL6lUEWv8TkBIX8CaD7U2eWC3ZaPnMXrjPINHpDRMw9mfUtlhRtEgk(wfw)CSFBv6gcs9WiD4s)SS2BXgQZgI3E7YAIEUbs3Ihu6Hf70LXsefpmrV9UnJyWrEhAIiso8ItNgnEqg1oShIi1ZqO70QYNJjDl(o5UBPhggjpZIsh5tAXoAuh2GRFgM)URAnm)VKzyJc2uT9(KTTFI(WA(YjLlR8RJZFRH5nWnf52WCuh6LUqqQaJlR9Skq(FPlXRgz8jwlZzaMOgeUrLBmDPKUlUxTboA6gtM2Un1upa5fs1Kn5RUUGUFkoiXv5q)hCL9BT)yt7kDxvn85PYQIfa3ameBmJN04ESaKfJM(v2epkVLoxwtLgi6XaBPWO7oPSoYU2TTbz8ynZCn(wrnu6kePopypE99xAJ5AtqyoOPH9E3T2RW7syTlV928LZAZgyjybzpI21Cd7J5VIW95k5ZMY3Y6fPHsqslGuEV91tmraS5to5Gtp97(OnFW5n03REpa7(kH18053sc1TfBUPCMlj9cJuSq5PMvjny1iz9uMf5(dMchnjrgFEl)kzI3hk(Y6dg7LLBSXKUEW2aHuaRUtsJymIsJJsJLkLp8sXxCuQmgQ)IJvPPyXxg1eQmJ2OesfmuxMOfzsxyXzGNsIaMaHrLKfflLMmxRvLk0ne9QqFn(mxkikOOTXNyT9XyrQaJXc(Jdck2MwtLW4eK2XS50kPovNL)vtbsDa5)lZ38O1P6vXDXzBG3l3Ua6LKLiecToZgYoG8QZL)2ZfjHkBfCgv0y6JZkHq)u349cySrt83TgKKVWoeNDhV7e38to0pUS4niBmEHq5Kc6BlBCcDZJn2itWSAJnoypF4C8mGNF67dV(qRIfbJqZJmqbumXp2o9tFH0n1zwuZH7P(ii4sOG8BVJwEANoYxmWuwzNvXEiUMxyo3j)L8fovm9hCOGBUZWZIrxBFTxDP(SY15UVRxuEz(BCNBapF1QIPo3N5I7V362(sKMfZVcmUUdKGJtzrXxSPqNlorwDoZV9wNRaSACy(kWOVBVswTM2E305ZM4YcMzoHUvR2(JZqvgjWJdfdpvTZmBUTwBKc9k5EXYytAAuAsTJuf7fffjIJJmrsVJxPEFFct0yFEdRr7ikYml6hVllAtHnstGoTaBd853YKZF9Ph4mZUzQstKNNVyY9yBOZNSK0YifX0ZaCSZiIJBbYdxAsnsrMqBu8MWBf0RPhiwqVeSzY)09fRE0YvouJ4pMD02CNSeED3A1IMf4frinbccnXPzjkygM0gBDrJ3dpsPz(bOZeISOK0ykbwM14ZPJsHGwijYebr9PgzQ)7TEmKcCJmQmDgesRm2CtaLOYDwhPJuQyielonbRawP70VWEpsEKrfhLLPKrwH86i)x79m0r8m2ILUuvkg5Uu2H9CLxUocFUjIPyGjtIwQ67d9x1rktImbdmLwBmUeBWvMg)gIHrwAwCgiqQitsk98Rux5DYJmMiTqHgbI)Js1k)u06ysm)turjjXqjwuwIUAi48k4rA0EPXPQ4yjps5(5NphtY9IuBjOnquxRGIwN7BJD8eo5vUS3Z4URqdAf)LOCtA(133g0v9wz32G4odKMpUvLgspq4PqpS8FDZNHglp78BhgsTATV2PGVBEXzs7GBparVEQSzi5bUOQW7Y275y1gGRXL(0wz6nUl53N(7F1RE6tq5jGdWY80NqPXV)Wnfl5NJpWnSF6t2mW5PpvI)Vn5dF6tqFKlhyyZ(hGqgxRoRQz7PrCLaDal(FB7E(H5lwy7FB7nhIeRAi33VP0(TvTRhgZ)UN(elkKIsVUIM8U7380NUbqBQBxan4gmWxU4XGoHFW0IW5F(I1LTkWMGXVl(zOVwxnjM90FpRnz1qBDLVGwzVGcvEnhWwKxCa6)23WVfTGpEBp9PVXRrgG3tI(Dp937Nu71Z927tF6)KTu)DU(1reylBvn4wycV3U)B5GPIeTgd(LBibWPnZrnRGwI)AopEaFZ1LCTHOACfWoOlxmdvZHGIun36p(dBp4h(BwDFrW4FaOR25alQFsyXVgq9aEdmQQVO1BrFKbnFNWm6insFJw7rE)CWfcsmfwu(GJmrhSJ)2v1MUGXjB4oP5Ui32DSW(oeWbw46lhuSwtHQM7)4zfxXX1(vF1r3V06m)1FZVZ3oWklY)rqlCf7pWniZSRiRk(NUF(k3wU)da(uzUFY9q5QphofuPrp9j0kQwCtDIU4En8tO8)DdxohmvxbRz8UFDHF1YZ4X7GCUxBbjT5R9FPfNr9h)ndXO0Z9zExMKMoKzUo45NwUmypvLOflVt1UckoLld1dYMbWvyFE4iOVdAQDiylOFmCdxsU9E7gh7wfBxxTC)q(QL2nhu6Gnpxd7qr4sHhSUVg2ngL37iXIO)oRKpckSJK0aXE9lofWhTm0tTTGv(SpnA)AeX7LRxvtRLuqO)pHwYwV1UvjF1TNfaBYcpbOKNSkh45lwoLogQWggBynuwQ90jQKc)pL(FM4(zK2(ZevS7VfUFktL(ppY)5P()w5(74y)FR9TJV(r(2v6RN0)5sx9agmF5mU)oPQF8)u6)CPVCc)FlQAhF)fxvpF58TRmlZPb)ZfpUEdrP3K0H12yWKG2N3NBQ12VLTq8cUNh4Z1K4YgGT8yHIahes7)gB)xH9FJ8zXbmyA1CxEv38Kmu9HmiN5W2JBkwuD19FXiqdbMI9p)8Zo(GpC(HtgF4jh(6ZNC(ho)0ZoE)t4c3yMNFlxxv2PBwTW)ok4YYTWo4nhpE)do5WjNoYIWEY73F0HNW2y85ND4(V7W6dZYrhFg(OpmIF3HJE9Pw46toaf67EZP)WOjV)B3F8HJB)TvNmMd2)KtoDu7X4rF4Ktqbo5qmh(HJhH2yOw26yS9)Wz7BB9Jo9S3EyDtXpPQxoE0rN2UpSbJ1TM6n88sIt8s3bUFexCACbmdhVDCmXMoetE3(F3XJERTDEhp6rN(Ud2h05JF3H8Jo97p8mmREZ(NV)eyFZiBrhrY9PV)8JpD0yhLCYPV)Wrh(gwdFK2b(ZLyp3uh2WV94Xy8(7DLnCsD)s7d3q1QUAGPzSZPP(boTYAYhgXFiCm29lUZvPAMEx8RpVcWmFqewAZ(hRmcV59v(4j8Zgjmg7zsDrjfdUH2MYexplkodFJswLx4FgG6w7o2saGmeGbgWhRoWV1(SzGAVXfA87OhDTxGiRzYn)OZLQJIJTXQjyiKitnAAjxSrkvsFAb5hcXV0qaggYC7sLjtJGfIvdHrTci0rgbnsuddiH10QSm39Nu4inRNrAAu7rAMeZwHknookwhR)6iwgwrDQacTJ0Ww3ThcIThcucDRHaS0otLkLcPsPTNyNaIv0qdHJsZYmc8FJfgyRTW0CGj02gul1XWsBqGylMgqapkb2vNOLPjWsBJmt2uv6mymLuXktKuLMvt7LvvvBKPzMutCeDZBWX0irQsmrqruAMsr1rvvvvv1i6tjmDJJfXOKbdyDIWKkWyL6RIe1v1hmlWqPtrHOhd0MK0SMQAIWifSQPyGfZ8eRQQ6kYuAwug0MsFjWF04SCd9)sepKmrcMdI1v1hKx22YiDewLvYmH7wa0v1(xZcx4JnbR8d0s24tLPAXnKyurzCPJNOLm3H0kANzi7V2p)UxmeAlajf62LXPyRb2fgRs)6gc9x7xqaczxAneaSgSCkWQcKb0Dim8EISOiDwssIcWwmj6awmJknvQJW(FSaargvdR69eSQqKc5SZafjnOQgSOjrZMXaLOBQQmOQImEZ3bgjWO2uv0LGCOLrMuqtK1Rh17jSvvbHLm54mgDREnjc1ojJ7xCFtB6Oiu(2aTeNGrgDlIRgcTWmIXoklkXYKWlEopXL(P755XI4rvYOX0vltIT8(MTfpNsoXyqoZePAVIetavRQ1IXU6mjDNPIoUSUyQom2AWwZyyX2Y6qrRK2rjTfiNabBjPAHalys7fdGR10Tlwe0WffHsd2I40MIz6m2uXAEhGMInUARxEDflTtXGgiqiaNQ17R1flRvX0y2b9H8u7HzGrwxmruBcNaINnGOKLcz3oHHP1x)dbtcJeLbAaIKyD0yjWz1x(dH9lelRJOKzST0Y57BVwReas(EXMS6B6HqQvmy(1yzxc6qG6erBIFIuistGgei5rLPcMGBr9JfrkE44WuvM00ETj)PqkGotKPboeOFlPzc2M(Z7NrbqBitfuzGQP9AVaKIglLBPKGG1IXT9cGbm2GbpH()wQIBAV42la9VpYIYOlDjkbsFGkQi(FAAV2BfGygjWIawiG9kloOCD2la6bGCaqsWiqHJo7kx71dOungIdIG(gLqe2ETxpGyJysw0OS8cVTPCMo0fmOYsWeb8bPo9LUY1E9GN8AkenofaQ02qd4PZTxpWAfWAOSBztsenTNSZgcP9iwcoftceD3SHq2fnMgStqbGkXY60iXPJKPKmizcOBsHACqfBAV2RhPrPzqBGeqLseUlbyF5uDOFr8c8mgm9rKg1uUocNmqeMIcliNtsdDw2z9ikdy7GsOejXqh0VMo894)cTsGtasvIA2hj7iFIhSuOyca6aZQOE)7ZdP3MFEb4sGeqLa7Ws4Mrrhi9ViUKER9lGlrNP7ansGTMGVsNflnvAe3DOr9v7xGkezZjVaCjecrCgdGhSokZZIvpesEHXGwcZm0uBIII3tgs1j2GJVxs5bPMWngTBTmksoM3oTW0LOMI1H90WJkJmHaNPQQ6IL0zxwFtTTuDc7kmmftaHmjwM0i8PJQZ0ybLran7IeVI40(uDQfqzn21GMmkRr1swho4eSDGmqsWjfhOXiQt5WgmOLf9EQFnUxvN8CZNbrNPcALty71r1zIMNjEuoRfnzdO6Ktd0CylMIAzJA2zl6k5gup8FP0cm(mnA06Swia25uuiy8cJW8oXR6sL1q7kH9DWaVmrc3nRBdZ7f9dqV1(fgc0PKTqAcW4zaMcqbNX7j8DuOXr8QDknlH22dXVzbW4XNXfwdKPb0zwdd86CRou(G9mcBEa3cuQKfyFQraYFgtAkbnt1ux1ky8AA0buvQfqHde5hcJhMIa2ziqwaOE125xdJhl8rrcMcvsamolW4bq6inmsBvD6q9fcCL7uWaIS14)HnHH2Id0aWigSdckIcSfVY0wfuKOTctqjKMaZ41kMTxja4hweXyFltBt1sG(cJvnTtmjPX0wy)ca7ryLGgO113eev7CPGcAlteTwhM)gfK9zWKaOmsN5YXGgpaKvvvG7lLgXdTPq3vCyVAWurru2smcAQA1oCiTdloy1dWaeqGwCZTTq)CzBTRhQzt3t2rZNmUp7HtAZfdeugiLGMQuzTq6oVrQ)A)IMKN9mdHmHtWXpTHqvTFHHqAhXjWUETXANBQIxEfTfNOFjpLbzOeTp9Be191DFB1iLkPeapTWAstu39O1irjShUvxlQqIQ3wZx)d5T08bLOe6wug94vKSPyDHjJYHsaUnSzSbU)ZdGW02zFj8taExiEYWBBLocL1Viigzk1PcHnjsxMF2hacca2G)HzsdT5BaBVv0o(icYmrzrB1VT30FGGab5iqmtiE0oM)17uBlYOn9KsGbykuQOa4iDbqKaHU8UQrKMMOgY27uM)v0JL0ZIzzYbaqaOsa6Rck0qFgIAPlaccofQXJjNvwy56Wohdwzyuc6XyGryyaegOUWYYaz5jXIHaqGzGHEpfY2IGAgXGaiqxgX3la0MyfZmOP4Wq8uUMfrND5CxswpMIJXxmSfbAUuCaKUTKbrFGIB5SoywC6o49iRNEG(taTb2HKz7Rkb4a0eSRZGsKKjIud4WFARdSxKHAuNg6G5TGfJLhyVi9oIqQhq4aKgcicg(Vg6X6beoGgYcvxtVQjdkwxyXszQHiDfAtMu3vHBn)fy8HOyucJouuthyXGkaKNGDamo(9i6T5QHmlIyqs)sc4NXd5rPeSzcdRyq5acAtdfPlxn2sc7DtiMLwgq3HRwPjoijTLIKNgAsxUAEJJzKswkDOB26WvRz6oMOLyNNeOVc63KUezgTdyDK9MpQH611btGv2MJ8angSoUbPxhhmr09q0pKhakOpojMECWeWqfzOf5WKhrOzBDCWKM4t009Za)KoAqhmHrp9tnTiUk7r9kdfBT7mMULocYgAjTVJugyxhyOiApj2o34d14UMPezvGatbTEsPPCDf4djwrWcaqEsd5RA7GPrUqy0XBsGhJX8gWkvrjQaVH21BskTgA6XOgd5KWoPJ3KS(EeQZaegEF0nK3K41GfJGK9E9Yem564njfFQIIT(43Afyt56ehd8FGUa6QqyBxy56q8HIhMNWqtaDHDwt56q85fwBgmRH39AEuQ6E8Me9yowDW2qOamnS96AVUcBLJbFb3APByo64njdHRdG1jutL37OME8Med6QbMXWhJgSLTzDRR3KatlJIhynaAUKa6swN13e61Ny6aayLr224Et6b3Rq2XRtOlsDh0fShq)1H7T)A)IMrN2ncXcnnWhntSl0Dbri(L84daofz4v9MMxrCHB17uS(6KTbSzW2xMs5WmwvAtW5BRAdI1n(d(zsxwlY1KQJOBiBKZ(8MIK2oaLAgwyf1IbJmtfFTMI0BTFXHqAh3kqDfWgqOzPYGpZUpe6T2VK1qrTXXdTuqykdJKqbEm1xNVi7V2VOViBVqKs5xqEUrRG9avs93ztjagmyWT0KATYpq5xxlYO3lW(y6oHOaxBj76YsGUaqraPLPuXa(I0KrphGoeZCzsKCiFr27uRhlYGOVmOSnjkLY9hWucDQI48GbajmK)MH8fzeNMSPWmwindzkbueBiy5iy5u8W(IKUrjJNddzkD(JUbcEhHu2miqB92gtHIHnLiZOTEpord6tYG(ImYWuSaRw0jIIbnLGNldduvYOCq)HnOVizavbWgjdfwAwTFZ7c6cqgucG2cZwONoA34PteTDyykXURaChjJ2BSAhtCOJOn5aQpdbFgdFwTNWavmR(0CxzicF2cPB8mylO)ap6DrimxgcjPdZTQU2k7xSxmOQy0GXqyEyIZOiwxWDbe5gv9ipWfHyrbS80dqzXCfSX3xyYYDee)cekeu1kxeAGXTGrI2PbbroVlM4TsMEphyXJJLaPOOUQDWaal8jFle5bExNEd1wBugPeY9GKX2oilRVaZi6MqbqvlaIqwexao)Aeg2BTFXyd1XVkmoiG7lHHxpQBsu9Iaf6T2V4qq1jP3ORnJfXraYtSo5RZnH9x7xmV76eKUuG6wQyKxTN7S2uHxcRcL7jLG5NE)owmuE3rxviKm4U0B5zrdIvbnddBc2nNzQUdD325s0DF8weZWuxkt1n1Vcq(iPp8q7bi5ITtlXEqtM2nTeT(2oLITz0F748n1lMzK9v7TjpqMkGL7CPVkWiWUbxMrVhwZsnCEhx1JV3GKzqhHeNu21YDcYwCCBh0qtuOSfPvXqI5Rmsq9x7xcSshiBq8yg4QadJj1NdvH5z5lXAAGIpDetGfJvq3GUpgRm2WwfBaW70bCFC)dMTP9sOeid4XzYoLgGqQdQAmGOh2ZuX88GMnGhIyUgbXCAgbqDy2Iy2ctJI6azKrLXIH87jMPWEbynawrGfQdf4u6Z6yIViIjN0GEikLp2XatwmJRwRuYPJrXmaXPehquI0)AU2hyLuMUrakykbC59ysFGvm2ZyRalcgMSdbE0r1nWUaLKqrFERLzzd63tGde78GGSghNL(Y(OVJrNyZnpd0wMj9wbo9f9rpGIkjdgtq0K4H4v7Vx2ouhzeZa0lr3Mh6BSUUqJl0Pm9Rihw8a8QkGosq3GdWsmLPgkuh2YrOqmbesvdKFCahvQss7P0zu69q5hxQeGu00(b(MmKnu(XbEbBYRIIZGaoO3mHOGuMsvGZp1lpY0hWAG2HoKZEDRBc59J7s6ITapGoVOwErTJeBRRZKyRoJTCyAM11bozWAjyWbjWrbka6WRQzeSGQKmS3mj0wOUaRXOJihX2Cz14Bh8Ir7yycLimvcYiNKrA6K4kQxoTIzE7iPKj6YPUjuETlFIGzGGMRzCyndL3k9pw2ILgQB0wpiRmmMnID0BfDM30R3Ob0GZsjt(ktN6(R9ljojRtsqOGbjmXByanXMQoQ(EgJAGT5WsidSGKU9wgeTCmMIXokASf(3H8Qu)982PGBc9LeFGRT(amDa1HkQVuj4TtaZ21OHqQLYBnaaaIjmAAq(d0rDygW6YmQa7MKEno9eWeBk6W7IGujZkUOUzJW2P6OnfegqDiK8XiNQHKYyDyc92reJMjZdpLdAO00NAT9PoKWduWUbQ7Kzx1qIysSXKc6WeA(20enKiMWmjeAL6XiGEYxbG1r3zVo9bFef7vN2Yj78PVHMuQmwmPmxogYkGeg(cdJ3vIff72aY7BK2XxIPrOUKYaIOXDzv8vaih7k0gMBJrwpOmu20bJ6YIzm3iJRwneOqGxNPMycmbsceeMbcBOMhTjPkYadsIns9oDKFaZr7vOmmY5Gsa6SkY0XA1xenmngcA0G9iwFRxBAv7BmpL0SNOhtpmwzzsQDKHZsoGLzgMosIuMOoqFNu31TenU0RN5Y2UGGxeisUlfy98XEs1dKIKufKhboyWc6Zdi1273nKPNPLa3WejA60UXGaZpgVFHnHVJAYmOoz8nMck6)ecy1Zj1xgeba87XSmY9F6d4RHaDemkkYeE2IAAPojBVizpzQQp4d84ObjIABleCGM6aFGj2ctDmgbng42T3aA2MrufTLfXzWEFbTBHgw12z(rdZh6E4rgO(dBw(Ec)(Hoh6jnVb4zu9zwWvfZWD(ePqtBarhS0e6yyc73vATGNYpizlPkjKn964cSVwblisS6ugYYCgeCPIhhf79yZaUYwLO5bjagUWJPwa6sDxG58H5ccs1j8CcmaIBDQGavHm6KOQWj1BA1kzIwZx6lkwnAixzdXN8KnLrFahl0dMvmgMn6mJmzQzPthmTA5PdHIJZK2tu3qwhYTUmoaOfRXjM1N1HrgMhMWILmMB)IMYP66G)mnwuHLsjsORDiRdTNGWiFEHa4mdH4gM3AOnPk7tRvA2GhqfyeceUytNJiTsm0bub2KQugnBtyxC8Ghqfo(vrmL2I4XWm4aw0bEc4m5f2h9XxKjiRI6M)aaMn48SPiUmnQo7E6M)aa3N0UObngXUBRkF56aumZEIhj7G0ycs2QTYFaiqaSD0VizrXnP5CNdOsc1yqcneZbgW0HoGkGfGE)lLRBv5vAFhqfcwuP4Hcg2DfEal6KsbAgKBLcWk5rDonO96S)qXCbdMZW4XJPE98Otkf0V4RTtPaDcxBbGwJna6n05oPuGcI05P(d4NzCRndKsbKnB78haG(4lAwSMzqu4Mq5w40nm)iPjoPPIKHonk8egNO4(kWBMjByY7EAu0PmrkTPOduNkg60OyJHnpnkj29cr7K5SrPXDDNOjHPCnAcaQCNbqDem1H5XL1l5mjZdpsV91KBBtfnmGzGgvoRdoC6DwA0P7XCpB70otW06hBJ0y91DYw71kkGzHXOMxLBXEVfM0xYusz3mzzbSQeZqwrLYdkUe2va(Uyvw6aPDMcW4IShawWj7pcij95OgiGKjblGkZxFUgN21XPIjakduROWCMMqpyANfZ0zKhc)mQsOj767Q2GrNj1AcAAsCaq(UoQHzsbKaL4YsDXqov0yV8dXamc0K4apW1fPfMW4)hXuSh)REO0od60i6cazqstOI326T4(qK1X0a(aDgtJ6ThEUS2rr65p5ZP0LsmLXmjrbrMulz8TYOTNcpY7SW4HYmkwySxOGMQZcG)yeawqGOIbWoLrrVzVFDvHHMupjpOYOKHN2I(MhbXdf6yzWAzhWxJ0Wbm0dQZu2JAOWhnU20rrOiIbAjN9MD9cgFUWt4bxwY74W2wg)s2BcDqG8Wm)nRoDP7lxEyETW0gtr3HfSdx2vPg0MLWZsLknk4opOd2MiMDUsL06ZIuZ2W83YEZn1pXolwumBI9jDS9fmI9Ma9bEbXDX4Z2)43084iD5J27EPQ7s0v5vVHHDUwE2WRKVwxspB65A6XEnZYxjPBMVXFL(vUCcFq8ij3)cD4E1LA1X(Y6Fh7QVstT3MQTVO)4n83SQbZw1myazFZuHbJmQ)zm(9j1j8oFZu10fcciWI3je1NLUGBd3to8OUZ2Iv2N4iEjU6jFU3HC)Rms7B(3w3wXCnJex3Zg46P27Yf7DIB(c7npZ6c(gf38cL4VtzlwD9JnxZLURxMZYNp7O5lNT1Dn8Vy94bb3WEB9u))l688xVE7D2BANFT6T9T3ST)ksiTay)vNzr9RvVYlA6Cis0D3WXRb4Q7jBj3V3C5dZlD46BGy7BnEpYyQUmr5v3S9EkLYCET9vd3EnXVouvH9jzA8(3ZBMq(aYzVnR77DX9hkYVdJGdWmkQLxlTkbhF4YVmFv5sEHs)0N(MJGO85lV(31BRzhetEx(1ZNo5iEPzwSILpuLtscmeZ2UJNwE)QR5ZRWMvZ)mVWlF)npYNy6f)oxxtfJHxrjJu9mEEdwiwo4aAF71))JtgF)vxvsYyi(2KENEBMF99fp30B)vtZxwm5Dqs37SVnupgIgw3xJoF1aTO9zj(EYeCexyzbhF38vZ3eIC20ttEs(xYF(P8z38yj(LBM89LlWaUmeKDApT44fZVT45BYxVcRP8Xk(9LZxdoMO4qi5qzM01WhTQC9Mll51T438U5RwX7CYJ5wc3cldHyhy6kMFI26(TLpSWE7nEWc79c638UCETfEU91YOP(szl47kgtEB9pz(xCvV82lrTl(X7wuYnyv8uWyNOwi6JT5OHTUhKV6ZRVB(sEho(nNVA(Yp30L86sQfcF6wKm3897aRWcE7LoU8(fDRQMhBhzlq)Im(GD7hU270Z67C13LVAZJ8k68n5TiyzY2UrsW7sh3m(TlYNZlkYZl5v853u9N)7JRQCSu2onjP1gIyF)xU8Vbv7TaBvr3HobIOIA5UjywwQNA9dfx(aVIkxX67M5VT42UTb2fZlqYqxrX7ClzMJf8U5ZkUD(0bwN1rADlVtfB4HwWTyTOSC2JyH2Eta3D5shf1(8UGXb9GAVSy7xEyxoRA)xfZ4AS1GnOgvJX4agkSE1mgF6tFB(Mv2l32odsgB(wo3cvv4YNsSWa9fRSdZ3x(G9UEg8i)J5l(d5Z)XTiYjk(K)e6)RyERV7AQJVEPf7j5UUUGRwhzVfx7mCONZLTpCnXg(O2xXLnBEomhH1)DfZOAa2KDhiX8LPk0XzGHzqb(JT3B2Df3h3WSLg5oyEJHqmizMR0EA6HvBS7oesyE(f1YxBCAKMS904G8zx3dVdVZwA5doy9MwvTIcBqS3rSF3CEVm)nVpF9ASFZ338OtM0YVCcMQSQNDJQO7g1AN1LXe82PgN3nJEj1tH(Hg1K2XB7JdKD(A2E(E4TaUZT9WhkD(xskdBaX2nWXlxphmt59iEmjs0YfGugJ2n2F9n2BX7AzCNDFpsyjNJjQL3bJT31v2M4SYntxbCoCx03J1)sGP5nLl2syRGb0t3(WhHMnZ9Kzn(h4T2)67SRFDQOgMT7NcnSFIiJJk86YL2BTCmfEtoVKN)byB(D2lv3oTJc2T5y)KPHZJKFYZJkUqP04EJyHSHRkUeBd4sj3oCB9QaZU)n2xVxVI(u6VsRozaT4s7vJ9qQKfwT5kr4LO)43vSOOyyOlpuUA2KixiBdL)L6GoEgGD5e1EEXT3vSElYESGPsPvXQQH5JXL1r2ZNMF3nLllVhe6xFd6STurXyB68MtfNhpo0UQ)T8o6)gkRWFd7xjNj1rLsQPSzjEOlCCUi3YS)9fRMnFQDih8Hqvp27TPgrbWDKQDOuRy44MHyViVpF)Ip7eIdnaCBuFuGSylJNQIXtqDSUPW(8jXzbbWp)QUi43F2myMWh9xM1FCoxoXp4BLuUTA8fS)klusvA9yJEk1lsD(mItAXghlqKmXl4uvXYzSUMkqt2y7tI)Upoix6m)dPFL)GC3k1vpFnvxaUUxmNv3F3M1Dmn7b3wn(y(ZLXLflaDD)FpVaRxBFAQUy8YIFenS7XRY3C3rFlTvB10a8zcE8QcEp86FeTT2Pnl)r71Y8y3f68KLqk)M8RzDlNoRYfuDBv)nP90YYfqF2s)7qgF(3wZNAh(4uC)TlDPyL1vu(3di7BI08f(RCB(GavSKAtEfVxDT9P)dCVgnvFR7PJZA26glYC3dJB1xt5sLlT3OZBQFWK4TUw9lDepM80lA3wmX)miDPFGHfTzZDJTZ9pmVU7V9jvV1uCO4)C3RxHZ66oZD3J7tWdNL9X5bcEjrXUuwMp9MUR0flMwY3MayF1IjvnH3aAw(jlPN)US1cTZy7vft9VjybV3rTxTBvj7t)qNU32p3W3(h7ROlNJxnF1A3BcUZhLo)T15bUclv0yCB1ROs1FiS6CXKM3PR63TiRz6JV1((MhBFr8MKVb4IU8(nUBACiTB(FaeT8fJxMBFMXCLXwKYjS3EMxUlACRW)KoBblyBe(KHT(KMv8L23mkND(0tTRBCUP7fKYohSpoY2xtWwdq36Z4L0ZJlQ8RzktLsEK5SbS24ZFfRFnHLxkgVgdpBuU8rbIrEGzAdV0KZ4bMooXNk3GIFJnZsKcEVxX4S4Zpt7lbfFnQ8pAlX2hTf(YG5FvWUHO(R8(S1xg)vczwu9MZ)ljzovrTpqfeVnH9jmTNmZlIzEnMWJ9DuA6FojZB6Y(7ElXIc2YfkGWlDDwxjMTKPwjCVExSn(aH7IT7oXg2xABVnIdZSpOe(oIpuz2h1f(wa6eOe82NV5Il()d")
					self.editBox:HighlightText()
				end,
				OnAccept = function (self, data, data2)
					local text = self.editBox:GetText()
					-- do whatever you want with it
				end,
				hasEditBox = true,
				timeout = 0,
				whileDead = true,
				hideOnEscape = true,
				preferredIndex = 3,
			}

			StaticPopup_Show("detailsInstall")
end


function DPSTANK()
E.db["actionbar"]["bar1"]["backdrop"] = true
E.db["actionbar"]["bar1"]["buttonSize"] = 30
E.db["actionbar"]["bar1"]["countFont"] = "NotUI Font light"
E.db["actionbar"]["bar1"]["countFontOutline"] = "OUTLINE"
E.db["actionbar"]["bar1"]["countFontSize"] = 13
E.db["actionbar"]["bar1"]["flyoutDirection"] = "UP"
E.db["actionbar"]["bar1"]["hotkeyFont"] = "NotUI Font light"
E.db["actionbar"]["bar1"]["hotkeyFontOutline"] = "OUTLINE"
E.db["actionbar"]["bar1"]["hotkeyFontSize"] = 13
E.db["actionbar"]["bar1"]["macroFont"] = "NotUI Font light"
E.db["actionbar"]["bar1"]["macroFontOutline"] = "OUTLINE"
E.db["actionbar"]["bar1"]["macroFontSize"] = 13
E.db["actionbar"]["bar10"]["countFont"] = "NotUI Font light"
E.db["actionbar"]["bar10"]["countFontOutline"] = "OUTLINE"
E.db["actionbar"]["bar10"]["countFontSize"] = 13
E.db["actionbar"]["bar10"]["hotkeyFont"] = "NotUI Font light"
E.db["actionbar"]["bar10"]["hotkeyFontOutline"] = "OUTLINE"
E.db["actionbar"]["bar10"]["hotkeyFontSize"] = 13
E.db["actionbar"]["bar10"]["macroFont"] = "NotUI Font light"
E.db["actionbar"]["bar10"]["macroFontOutline"] = "OUTLINE"
E.db["actionbar"]["bar10"]["macroFontSize"] = 13
E.db["actionbar"]["bar13"]["countFont"] = "NotUI Font light"
E.db["actionbar"]["bar13"]["hotkeyFont"] = "NotUI Font light"
E.db["actionbar"]["bar14"]["countFont"] = "NotUI Font light"
E.db["actionbar"]["bar14"]["hotkeyFont"] = "NotUI Font light"
E.db["actionbar"]["bar15"]["countFont"] = "NotUI Font light"
E.db["actionbar"]["bar15"]["hotkeyFont"] = "NotUI Font light"
E.db["actionbar"]["bar2"]["backdrop"] = true
E.db["actionbar"]["bar2"]["buttonSize"] = 25
E.db["actionbar"]["bar2"]["buttons"] = 5
E.db["actionbar"]["bar2"]["countFont"] = "NotUI Font light"
E.db["actionbar"]["bar2"]["countFontOutline"] = "OUTLINE"
E.db["actionbar"]["bar2"]["countFontSize"] = 13
E.db["actionbar"]["bar2"]["flyoutDirection"] = "UP"
E.db["actionbar"]["bar2"]["hotkeyFont"] = "NotUI Font light"
E.db["actionbar"]["bar2"]["hotkeyFontOutline"] = "OUTLINE"
E.db["actionbar"]["bar2"]["hotkeyFontSize"] = 13
E.db["actionbar"]["bar2"]["macroFont"] = "NotUI Font light"
E.db["actionbar"]["bar2"]["macroFontOutline"] = "OUTLINE"
E.db["actionbar"]["bar2"]["macroFontSize"] = 13
E.db["actionbar"]["bar3"]["backdrop"] = true
E.db["actionbar"]["bar3"]["buttonSize"] = 30
E.db["actionbar"]["bar3"]["buttons"] = 12
E.db["actionbar"]["bar3"]["buttonsPerRow"] = 12
E.db["actionbar"]["bar3"]["countFont"] = "NotUI Font light"
E.db["actionbar"]["bar3"]["countFontOutline"] = "OUTLINE"
E.db["actionbar"]["bar3"]["countFontSize"] = 13
E.db["actionbar"]["bar3"]["flyoutDirection"] = "LEFT"
E.db["actionbar"]["bar3"]["hotkeyFont"] = "NotUI Font light"
E.db["actionbar"]["bar3"]["hotkeyFontOutline"] = "OUTLINE"
E.db["actionbar"]["bar3"]["hotkeyFontSize"] = 13
E.db["actionbar"]["bar3"]["macroFont"] = "NotUI Font light"
E.db["actionbar"]["bar3"]["macroFontOutline"] = "OUTLINE"
E.db["actionbar"]["bar3"]["macroFontSize"] = 13
E.db["actionbar"]["bar4"]["buttonSize"] = 30
E.db["actionbar"]["bar4"]["buttonsPerRow"] = 12
E.db["actionbar"]["bar4"]["countFont"] = "NotUI Font light"
E.db["actionbar"]["bar4"]["countFontOutline"] = "OUTLINE"
E.db["actionbar"]["bar4"]["countFontSize"] = 13
E.db["actionbar"]["bar4"]["flyoutDirection"] = "UP"
E.db["actionbar"]["bar4"]["hotkeyFont"] = "NotUI Font light"
E.db["actionbar"]["bar4"]["hotkeyFontOutline"] = "OUTLINE"
E.db["actionbar"]["bar4"]["hotkeyFontSize"] = 13
E.db["actionbar"]["bar4"]["macroFont"] = "NotUI Font light"
E.db["actionbar"]["bar4"]["macroFontOutline"] = "OUTLINE"
E.db["actionbar"]["bar4"]["macroFontSize"] = 13
E.db["actionbar"]["bar4"]["point"] = "BOTTOMLEFT"
E.db["actionbar"]["bar5"]["backdrop"] = true
E.db["actionbar"]["bar5"]["enabled"] = true
E.db["actionbar"]["bar5"]["buttonSize"] = 30
E.db["actionbar"]["bar5"]["buttons"] = 12
E.db["actionbar"]["bar5"]["buttonsPerRow"] = 12
E.db["actionbar"]["bar5"]["countFont"] = "NotUI Font light"
E.db["actionbar"]["bar5"]["countFontOutline"] = "OUTLINE"
E.db["actionbar"]["bar5"]["countFontSize"] = 13
E.db["actionbar"]["bar5"]["flyoutDirection"] = "UP"
E.db["actionbar"]["bar5"]["hotkeyFont"] = "NotUI Font light"
E.db["actionbar"]["bar5"]["hotkeyFontOutline"] = "OUTLINE"
E.db["actionbar"]["bar5"]["hotkeyFontSize"] = 13
E.db["actionbar"]["bar5"]["macroFont"] = "NotUI Font light"
E.db["actionbar"]["bar5"]["macroFontOutline"] = "OUTLINE"
E.db["actionbar"]["bar5"]["macroFontSize"] = 13
E.db["actionbar"]["bar6"]["backdrop"] = true
E.db["actionbar"]["bar6"]["buttonSize"] = 30
E.db["actionbar"]["bar6"]["buttons"] = 12
E.db["actionbar"]["bar6"]["buttonsPerRow"] = 12
E.db["actionbar"]["bar6"]["countFont"] = "NotUI Font light"
E.db["actionbar"]["bar6"]["countFontOutline"] = "OUTLINE"
E.db["actionbar"]["bar6"]["countFontSize"] = 13
E.db["actionbar"]["bar6"]["enabled"] = true
E.db["actionbar"]["bar6"]["flyoutDirection"] = "UP"
E.db["actionbar"]["bar6"]["hotkeyFont"] = "NotUI Font light"
E.db["actionbar"]["bar6"]["hotkeyFontOutline"] = "OUTLINE"
E.db["actionbar"]["bar6"]["hotkeyFontSize"] = 13
E.db["actionbar"]["bar6"]["macroFont"] = "NotUI Font light"
E.db["actionbar"]["bar6"]["macroFontOutline"] = "OUTLINE"
E.db["actionbar"]["bar6"]["macroFontSize"] = 13
E.db["actionbar"]["bar7"]["buttonSize"] = 30
E.db["actionbar"]["bar7"]["buttons"] = 5
E.db["actionbar"]["bar7"]["countFont"] = "NotUI Font light"
E.db["actionbar"]["bar7"]["countFontOutline"] = "OUTLINE"
E.db["actionbar"]["bar7"]["countFontSize"] = 13
E.db["actionbar"]["bar7"]["hotkeyFont"] = "NotUI Font light"
E.db["actionbar"]["bar7"]["hotkeyFontOutline"] = "OUTLINE"
E.db["actionbar"]["bar7"]["hotkeyFontSize"] = 13
E.db["actionbar"]["bar7"]["macroFont"] = "NotUI Font light"
E.db["actionbar"]["bar7"]["macroFontOutline"] = "OUTLINE"
E.db["actionbar"]["bar7"]["macroFontSize"] = 13
E.db["actionbar"]["bar8"]["backdrop"] = true
E.db["actionbar"]["bar8"]["buttonSize"] = 25
E.db["actionbar"]["bar8"]["buttons"] = 6
E.db["actionbar"]["bar8"]["countFont"] = "NotUI Font light"
E.db["actionbar"]["bar8"]["countFontOutline"] = "OUTLINE"
E.db["actionbar"]["bar8"]["countFontSize"] = 13
E.db["actionbar"]["bar8"]["hotkeyFont"] = "NotUI Font light"
E.db["actionbar"]["bar8"]["hotkeyFontOutline"] = "OUTLINE"
E.db["actionbar"]["bar8"]["hotkeyFontSize"] = 13
E.db["actionbar"]["bar8"]["macroFont"] = "NotUI Font light"
E.db["actionbar"]["bar8"]["macroFontOutline"] = "OUTLINE"
E.db["actionbar"]["bar8"]["macroFontSize"] = 13
E.db["actionbar"]["bar9"]["countFont"] = "NotUI Font light"
E.db["actionbar"]["bar9"]["countFontOutline"] = "OUTLINE"
E.db["actionbar"]["bar9"]["countFontSize"] = 13
E.db["actionbar"]["bar9"]["hotkeyFont"] = "NotUI Font light"
E.db["actionbar"]["bar9"]["hotkeyFontOutline"] = "OUTLINE"
E.db["actionbar"]["bar9"]["hotkeyFontSize"] = 13
E.db["actionbar"]["bar9"]["macroFont"] = "NotUI Font light"
E.db["actionbar"]["bar9"]["macroFontOutline"] = "OUTLINE"
E.db["actionbar"]["bar9"]["macroFontSize"] = 13
E.db["actionbar"]["barPet"]["buttonSize"] = 27
E.db["actionbar"]["barPet"]["buttonsPerRow"] = 10
E.db["actionbar"]["barPet"]["countFont"] = "NotUI Font light"
E.db["actionbar"]["barPet"]["countFontOutline"] = "OUTLINE"
E.db["actionbar"]["barPet"]["countFontSize"] = 13
E.db["actionbar"]["barPet"]["hotkeyFont"] = "NotUI Font light"
E.db["actionbar"]["barPet"]["hotkeyFontOutline"] = "OUTLINE"
E.db["actionbar"]["barPet"]["hotkeyFontSize"] = 13
E.db["actionbar"]["extraActionButton"]["hotkeyFont"] = "NotUI Font light"
E.db["actionbar"]["extraActionButton"]["hotkeyFontOutline"] = "OUTLINE"
E.db["actionbar"]["extraActionButton"]["hotkeyFontSize"] = 13
E.db["actionbar"]["font"] = "NotUI Font light"
E.db["actionbar"]["fontOutline"] = "OUTLINE"
E.db["actionbar"]["fontSize"] = 13
E.db["actionbar"]["microbar"]["backdrop"] = true
E.db["actionbar"]["microbar"]["buttonHeight"] = 24
E.db["actionbar"]["microbar"]["buttonSize"] = 24
E.db["actionbar"]["microbar"]["buttonSpacing"] = 1
E.db["actionbar"]["microbar"]["mouseover"] = true
E.db["actionbar"]["stanceBar"]["backdrop"] = true
E.db["actionbar"]["stanceBar"]["buttonsPerRow"] = 1
E.db["actionbar"]["stanceBar"]["hotkeyFont"] = "NotUI Font light"
E.db["actionbar"]["stanceBar"]["hotkeyFontOutline"] = "OUTLINE"
E.db["actionbar"]["stanceBar"]["point"] = "TOPRIGHT"
E.db["actionbar"]["vehicleExitButton"]["hotkeyFont"] = "ITC Avant Garde Gothic Medium"
E.db["actionbar"]["vehicleExitButton"]["hotkeyFontOutline"] = "OUTLINE"
E.db["actionbar"]["vehicleExitButton"]["hotkeyFontSize"] = 13
E.db["auras"]["buffs"]["barTexture"] = "Melli"
E.db["auras"]["buffs"]["countFont"] = "NotUI Font light"
E.db["auras"]["buffs"]["countFontOutline"] = "OUTLINE"
E.db["auras"]["buffs"]["countFontSize"] = 12
E.db["auras"]["buffs"]["countXOffset"] = -6
E.db["auras"]["buffs"]["countYOffset"] = 23
E.db["auras"]["buffs"]["timeFont"] = "NotUI Font light"
E.db["auras"]["buffs"]["timeFontOutline"] = "OUTLINE"
E.db["auras"]["buffs"]["timeFontSize"] = 12
E.db["auras"]["buffs"]["timeYOffset"] = 6
E.db["auras"]["cooldown"]["hoursColor"]["b"] = 0.96470588235294
E.db["auras"]["cooldown"]["hoursColor"]["r"] = 0
E.db["auras"]["cooldown"]["override"] = true
E.db["auras"]["debuffs"]["countFont"] = "NotUI Font light"
E.db["auras"]["debuffs"]["countFontOutline"] = "OUTLINE"
E.db["auras"]["debuffs"]["countFontSize"] = 12
E.db["auras"]["debuffs"]["countXOffset"] = -9
E.db["auras"]["debuffs"]["countYOffset"] = 23
E.db["auras"]["debuffs"]["timeFont"] = "NotUI Font light"
E.db["auras"]["debuffs"]["timeFontOutline"] = "OUTLINE"
E.db["auras"]["debuffs"]["timeFontSize"] = 12
E.db["auras"]["debuffs"]["timeYOffset"] = 6
E.db["bags"]["bagBar"]["font"] = "NotUI Font light"
E.db["bags"]["bagButtonSpacing"] = 0
E.db["bags"]["bagSize"] = 36
E.db["bags"]["bagWidth"] = 366
E.db["bags"]["bankSize"] = 28
E.db["bags"]["countFont"] = "NotUI Font light"
E.db["bags"]["countFontSize"] = 12
E.db["bags"]["itemInfoFont"] = "NotUI Font light"
E.db["bags"]["itemInfoFontOutline"] = "OUTLINE"
E.db["bags"]["itemLevelFont"] = "NotUI Font light"
E.db["bags"]["itemLevelFontOutline"] = "OUTLINE"
E.db["bags"]["itemLevelFontSize"] = 12
E.db["bags"]["split"]["bag1"] = true
E.db["bags"]["split"]["bag2"] = true
E.db["bags"]["split"]["bag3"] = true
E.db["bags"]["split"]["bag4"] = true
E.db["bags"]["split"]["bagSpacing"] = 6
E.db["chat"]["fadeChatToggles"] = false
E.db["chat"]["fadeTabsNoBackdrop"] = false
E.db["chat"]["font"] = "NotUI Font light"
E.db["chat"]["fontOutline"] = "OUTLINE"
E.db["chat"]["fontSize"] = 12
E.db["chat"]["maxLines"] = 300
E.db["chat"]["numScrollMessages"] = 1
E.db["chat"]["panelBackdrop"] = "HIDEBOTH"
E.db["chat"]["panelColor"]["a"] = 0
E.db["chat"]["panelColor"]["b"] = 1
E.db["chat"]["panelColor"]["g"] = 1
E.db["chat"]["panelColor"]["r"] = 1
E.db["chat"]["panelHeight"] = 200
E.db["chat"]["panelHeightRight"] = 60
E.db["chat"]["panelWidth"] = 450
E.db["chat"]["panelWidthRight"] = 50
E.db["chat"]["tabFont"] = "NotUI Font light"
E.db["chat"]["tabFontOutline"] = "OUTLINE"
E.db["chat"]["tabSelector"] = "ARROW"
E.db["chat"]["tabSelectorColor"]["b"] = 0.20392156862745
E.db["chat"]["tabSelectorColor"]["g"] = 0.84313725490196
E.db["chat"]["tabSelectorColor"]["r"] = 0
E.db["chat"]["timeStampFormat"] = "%H:%M "
E.db["convertPages"] = true
E.db["databars"]["azerite"]["enable"] = false
E.db["databars"]["honor"]["enable"] = false
E.db["databars"]["threat"]["enable"] = false
E.db["datatexts"]["font"] = "NotUI Font light"
E.db["datatexts"]["fontOutline"] = "OUTLINE"
if E.db["datatexts"]["panels"]["Clock"] == nil then -- this checks if YourCustomTextName Custom Text exists
			E.db["datatexts"]["panels"]["Clock"] = {} -- if not, create its table
end
E.db["datatexts"]["panels"]["Clock"]["1"] = "Time"
E.db["datatexts"]["panels"]["Clock"]["enable"] = true
if E.db["datatexts"]["panels"]["Left spell bar"] == nil then -- this checks if YourCustomTextName Custom Text exists
			E.db["datatexts"]["panels"]["Left spell bar"] = {} -- if not, create its table
end
E.db["datatexts"]["panels"]["Left spell bar"]["1"] = "Versatility"
E.db["datatexts"]["panels"]["Left spell bar"]["2"] = "Mastery"
E.db["datatexts"]["panels"]["Left spell bar"]["3"] = "Haste"
E.db["datatexts"]["panels"]["Left spell bar"]["enable"] = false
E.db["datatexts"]["panels"]["LeftChatDataPanel"]["enable"] = false
if E.db["datatexts"]["panels"]["Middle bar"] == nil then -- this checks if YourCustomTextName Custom Text exists
			E.db["datatexts"]["panels"]["Middle bar"] = {} -- if not, create its table
end
E.db["datatexts"]["panels"]["Middle bar"]["1"] = "System"
E.db["datatexts"]["panels"]["Middle bar"]["2"] = "Talent/Loot Specialization"
E.db["datatexts"]["panels"]["Middle bar"]["3"] = "Gold"
E.db["datatexts"]["panels"]["Middle bar"]["4"] = "Durability"
E.db["datatexts"]["panels"]["Middle bar"]["5"] = "Guild"
E.db["datatexts"]["panels"]["Middle bar"]["enable"] = true
E.db["datatexts"]["panels"]["MinimapPanel"]["enable"] = false
E.db["datatexts"]["panels"]["MinimapPanel"]["numPoints"] = 1
E.db["datatexts"]["panels"]["MinimapPanel"]["panelTransparency"] = true
E.db["datatexts"]["panels"]["RightChatDataPanel"]["enable"] = false
E.db["general"]["altPowerBar"]["statusBar"] = "Melli"
E.db["general"]["altPowerBar"]["statusBarColor"]["b"] = 0.94117647058824
E.db["general"]["altPowerBar"]["statusBarColor"]["g"] = 1
E.db["general"]["altPowerBar"]["statusBarColor"]["r"] = 0.92549019607843
E.db["general"]["backdropfadecolor"]["a"] = 0.6985667347908
E.db["general"]["backdropfadecolor"]["b"] = 0.058823529411765
E.db["general"]["backdropfadecolor"]["g"] = 0.058823529411765
E.db["general"]["backdropfadecolor"]["r"] = 0.058823529411765
E.db["general"]["bottomPanel"] = false
E.db["general"]["customGlow"]["lines"] = 10
E.db["general"]["customGlow"]["style"] = "Action Button Glow"
E.db["general"]["font"] = "NotUI Font light"
E.db["general"]["interruptAnnounce"] = "EMOTE"
E.db["general"]["itemLevel"]["itemLevelFont"] = "ITC Avant Garde Gothic Medium"
E.db["general"]["lootRoll"]["nameFont"] = "NotUI Font light"
E.db["general"]["lootRoll"]["statusBarTexture"] = "Melli"
E.db["general"]["minimap"]["locationFont"] = "NotUI Font light"
E.db["general"]["objectiveFrameAutoHideInKeystone"] = true
E.db["general"]["objectiveFrameHeight"] = 602
E.db["general"]["totems"]["size"] = 31
E.db["general"]["totems"]["spacing"] = 2
if E.db["movers"] == nil then -- this checks if YourCustomTextName Custom Text exists
			E.db["movers"] = {} -- if not, create its table
end
E.db["movers"]["AlertFrameMover"] = "TOP,UIParent,TOP,0,-36"
E.db["movers"]["AltPowerBarMover"] = "TOP,UIParent,TOP,0,-74"
E.db["movers"]["ArenaHeaderMover"] = "TOPRIGHT,UIParent,TOPRIGHT,-460,-318"
E.db["movers"]["AzeriteBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,1,25"
E.db["movers"]["BNETMover"] = "TOPRIGHT,UIParent,TOPRIGHT,-308,-226"
E.db["movers"]["BelowMinimapContainerMover"] = "TOPRIGHT,UIParent,TOPRIGHT,-17,-226"
E.db["movers"]["BossBannerMover"] = "TOP,ElvUIParent,TOP,0,-163"
E.db["movers"]["BossButton"] = "BOTTOM,ElvUIParent,BOTTOM,214,161"
E.db["movers"]["BossHeaderMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-383,390"
E.db["movers"]["BuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-185,-7"
E.db["movers"]["DTPanelClockMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-68,-185"
E.db["movers"]["DTPanelLeft spell barMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,456,22"
E.db["movers"]["DTPanelMiddle barMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,0"
E.db["movers"]["DebuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-185,-153"
E.db["movers"]["DurabilityFrameMover"] = "TOPLEFT,UIParent,TOPLEFT,630,-373"
E.db["movers"]["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,0,180"
E.db["movers"]["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,-270,376"
E.db["movers"]["ElvAB_3"] = "BOTTOM,UIParent,BOTTOM,0,50"
E.db["movers"]["ElvAB_4"] = "BOTTOM,ElvUIParent,BOTTOM,0,83"
E.db["movers"]["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,0,148"
E.db["movers"]["ElvAB_6"] = "BOTTOM,ElvUIParent,BOTTOM,0,116"
E.db["movers"]["ElvAB_7"] = "BOTTOM,UIParent,BOTTOM,-315,349"
E.db["movers"]["ElvAB_8"] = "BOTTOM,ElvUIParent,BOTTOM,-317,347"
E.db["movers"]["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,477,-260"
E.db["movers"]["ElvUF_FocusCastbarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-516,-298"
E.db["movers"]["ElvUF_FocusMover"] = "TOPRIGHT,UIParent,TOPRIGHT,-516,-269"
E.db["movers"]["ElvUF_PartyMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,429,424"
E.db["movers"]["ElvUF_PetCastbarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-646,209"
E.db["movers"]["ElvUF_PetMover"] = "BOTTOM,UIParent,BOTTOM,-268,292"
E.db["movers"]["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,213"
E.db["movers"]["ElvUF_PlayerMover"] = "BOTTOM,UIParent,BOTTOM,-343,346"
E.db["movers"]["ElvUF_Raid1Mover"] = "TOPLEFT,UIParent,TOPLEFT,24,-195"
E.db["movers"]["ElvUF_Raid3Mover"] = "TOPLEFT,UIParent,TOPLEFT,24,-195"
E.db["movers"]["ElvUF_TankMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,477,-195"
E.db["movers"]["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,343,346"
E.db["movers"]["ElvUF_TargetTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-451,346"
E.db["movers"]["ElvUIBagMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-242,332"
E.db["movers"]["ElvUIBankMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-560,-227"
E.db["movers"]["EventToastMover"] = "TOP,UIParent,TOP,0,-183"
E.db["movers"]["ExperienceBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,40"
E.db["movers"]["GMMover"] = "TOPLEFT,UIParent,TOPLEFT,341,-4"
E.db["movers"]["HonorBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-264"
E.db["movers"]["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,0,25"
E.db["movers"]["LootFrameMover"] = "TOP,UIParent,TOP,-352,-599"
E.db["movers"]["LossControlMover"] = "TOP,ElvUIParent,TOP,0,-561"
E.db["movers"]["MawBuffsBelowMinimapMover"] = "TOPRIGHT,UIParent,TOPRIGHT,-95,-226"
E.db["movers"]["MicrobarMover"] = "BOTTOMRIGHT,UIParent,BOTTOMRIGHT,-534,145"
E.db["movers"]["MinimapMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-4"
E.db["movers"]["MirrorTimer1Mover"] = "TOP,UIParent,TOP,0,-112"
E.db["movers"]["MirrorTimer2Mover"] = "TOP,ElvUIParent,TOP,0,-129"
E.db["movers"]["MirrorTimer3Mover"] = "TOP,ElvUIParent,TOP,0,-146"
E.db["movers"]["ObjectiveFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-135,-300"
E.db["movers"]["PetAB"] = "BOTTOM,ElvUIParent,BOTTOM,-344,261"
E.db["movers"]["PowerBarContainerMover"] = "TOP,UIParent,TOP,0,-94"
E.db["movers"]["RaidMarkerBarAnchor"] = "TOP,UIParent,TOP,0,-4"
E.db["movers"]["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,0,0"
E.db["movers"]["ShiftAB"] = "BOTTOM,UIParent,BOTTOM,-211,78"
E.db["movers"]["TalkingHeadFrameMover"] = "TOP,UIParent,TOP,0,-201"
E.db["movers"]["TooltipMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-247,241"
E.db["movers"]["TopCenterContainerMover"] = "TOP,UIParent,TOP,0,-55"
E.db["movers"]["TorghastChoiceToggle"] = "BOTTOM,UIParent,BOTTOM,0,429"
E.db["movers"]["TotemBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,456,125"
E.db["movers"]["TotemTrackerMover"] = "BOTTOMLEFT,UIParent,BOTTOMLEFT,452,25"
E.db["movers"]["UIErrorsFrameMover"] = "TOP,UIParent,TOP,0,-202"
E.db["movers"]["VOICECHAT"] = "TOPLEFT,UIParent,TOPLEFT,38,-34"
E.db["movers"]["VehicleLeaveButton"] = "BOTTOM,UIParent,BOTTOM,310,537"
E.db["movers"]["VehicleSeatMover"] = "TOPRIGHT,UIParent,TOPRIGHT,-29,-278"
E.db["movers"]["ZoneAbility"] = "BOTTOM,ElvUIParent,BOTTOM,214,104"
E.db["tooltip"]["font"] = "NotUI Font light"
E.db["tooltip"]["headerFont"] = "NotUI Font light"
E.db["tooltip"]["headerFontSize"] = 12
E.db["tooltip"]["healthBar"]["font"] = "NotUI Font light"
E.db["unitframe"]["colors"]["castNoInterrupt"]["b"] = 0.24313725490196
E.db["unitframe"]["colors"]["castNoInterrupt"]["g"] = 0.21960784313725
E.db["unitframe"]["colors"]["castNoInterrupt"]["r"] = 0.87843137254902
E.db["unitframe"]["colors"]["classResources"]["MONK"][6]["b"] = 0.22745098039216
E.db["unitframe"]["colors"]["classResources"]["MONK"][6]["r"] = 0.047058823529412
E.db["unitframe"]["colors"]["customhealthbackdrop"] = true
E.db["unitframe"]["colors"]["disconnected"]["b"] = 0.2
E.db["unitframe"]["colors"]["disconnected"]["g"] = 0.2
E.db["unitframe"]["colors"]["disconnected"]["r"] = 0.2
E.db["unitframe"]["colors"]["forcehealthreaction"] = true
E.db["unitframe"]["colors"]["health"]["b"] = 0.58823529411765
E.db["unitframe"]["colors"]["health"]["g"] = 0.58823529411765
E.db["unitframe"]["colors"]["health"]["r"] = 0.58823529411765
E.db["unitframe"]["colors"]["health_backdrop"]["b"] = 0
E.db["unitframe"]["colors"]["health_backdrop"]["g"] = 0
E.db["unitframe"]["colors"]["health_backdrop"]["r"] = 0
E.db["unitframe"]["colors"]["power"]["FURY"]["b"] = 0.15294117647059
E.db["unitframe"]["colors"]["power"]["FURY"]["g"] = 0.49411764705882
E.db["unitframe"]["colors"]["powerselection"] = true
E.db["unitframe"]["colors"]["reaction"]["BAD"]["b"] = 0.25098039215686
E.db["unitframe"]["colors"]["reaction"]["BAD"]["g"] = 0.25098039215686
E.db["unitframe"]["colors"]["reaction"]["GOOD"]["r"] = 0.29411764705882
E.db["unitframe"]["cooldown"]["fonts"]["enable"] = true
E.db["unitframe"]["cooldown"]["fonts"]["font"] = "ITC Avant Garde Gothic Medium"
E.db["unitframe"]["cooldown"]["fonts"]["fontSize"] = 20
E.db["unitframe"]["font"] = "NotUI Font light"
E.db["unitframe"]["fontOutline"] = "OUTLINE"
E.db["unitframe"]["fontSize"] = 12
E.db["unitframe"]["smoothbars"] = true
E.db["unitframe"]["statusbar"] = "Melli"
E.db["unitframe"]["units"]["arena"]["buffs"]["countFont"] = "NotUI Font light"
E.db["unitframe"]["units"]["arena"]["buffs"]["perrow"] = 7
E.db["unitframe"]["units"]["arena"]["buffs"]["yOffset"] = 12
E.db["unitframe"]["units"]["arena"]["castbar"]["customTextFont"]["enable"] = true
E.db["unitframe"]["units"]["arena"]["castbar"]["customTextFont"]["font"] = "NotUI Font light"
E.db["unitframe"]["units"]["arena"]["colorOverride"] = "FORCE_ON"
if E.db["unitframe"]["units"]["arena"]["customTexts"] == nil then -- this checks if YourCustomTextName Custom Text exists
			E.db["unitframe"]["units"]["arena"]["customTexts"] = {} -- if not, create its table
end
if E.db["unitframe"]["units"]["arena"]["customTexts"]["ArenaHealth"] == nil then -- this checks if YourCustomTextName Custom Text exists
			E.db["unitframe"]["units"]["arena"]["customTexts"]["ArenaHealth"] = {} -- if not, create its table
end
E.db["unitframe"]["units"]["arena"]["customTexts"]["ArenaHealth"]["attachTextTo"] = "Health"
E.db["unitframe"]["units"]["arena"]["customTexts"]["ArenaHealth"]["enable"] = true
E.db["unitframe"]["units"]["arena"]["customTexts"]["ArenaHealth"]["font"] = "NotUI Font light"
E.db["unitframe"]["units"]["arena"]["customTexts"]["ArenaHealth"]["fontOutline"] = "OUTLINE"
E.db["unitframe"]["units"]["arena"]["customTexts"]["ArenaHealth"]["justifyH"] = "CENTER"
E.db["unitframe"]["units"]["arena"]["customTexts"]["ArenaHealth"]["size"] = 15
E.db["unitframe"]["units"]["arena"]["customTexts"]["ArenaHealth"]["text_format"] = "[health:percent]||[health:current:shortvalue]"
E.db["unitframe"]["units"]["arena"]["customTexts"]["ArenaHealth"]["xOffset"] = 0
E.db["unitframe"]["units"]["arena"]["customTexts"]["ArenaHealth"]["yOffset"] = -5
if E.db["unitframe"]["units"]["arena"]["customTexts"]["ArenaName"] == nil then -- this checks if YourCustomTextName Custom Text exists
			E.db["unitframe"]["units"]["arena"]["customTexts"]["ArenaName"] = {} -- if not, create its table
end
E.db["unitframe"]["units"]["arena"]["customTexts"]["ArenaName"]["attachTextTo"] = "Health"
E.db["unitframe"]["units"]["arena"]["customTexts"]["ArenaName"]["enable"] = true
E.db["unitframe"]["units"]["arena"]["customTexts"]["ArenaName"]["font"] = "NotUI Font light"
E.db["unitframe"]["units"]["arena"]["customTexts"]["ArenaName"]["fontOutline"] = "OUTLINE"
E.db["unitframe"]["units"]["arena"]["customTexts"]["ArenaName"]["justifyH"] = "CENTER"
E.db["unitframe"]["units"]["arena"]["customTexts"]["ArenaName"]["size"] = 18
E.db["unitframe"]["units"]["arena"]["customTexts"]["ArenaName"]["text_format"] = "[name:medium]"
E.db["unitframe"]["units"]["arena"]["customTexts"]["ArenaName"]["xOffset"] = 0
E.db["unitframe"]["units"]["arena"]["customTexts"]["ArenaName"]["yOffset"] = 18
if E.db["unitframe"]["units"]["arena"]["customTexts"]["ArenaPower"] == nil then -- this checks if YourCustomTextName Custom Text exists
			E.db["unitframe"]["units"]["arena"]["customTexts"]["ArenaPower"] = {} -- if not, create its table
end
E.db["unitframe"]["units"]["arena"]["customTexts"]["ArenaPower"]["attachTextTo"] = "Health"
E.db["unitframe"]["units"]["arena"]["customTexts"]["ArenaPower"]["enable"] = true
E.db["unitframe"]["units"]["arena"]["customTexts"]["ArenaPower"]["font"] = "NotUI Font light"
E.db["unitframe"]["units"]["arena"]["customTexts"]["ArenaPower"]["fontOutline"] = "OUTLINE"
E.db["unitframe"]["units"]["arena"]["customTexts"]["ArenaPower"]["justifyH"] = "LEFT"
E.db["unitframe"]["units"]["arena"]["customTexts"]["ArenaPower"]["size"] = 14
E.db["unitframe"]["units"]["arena"]["customTexts"]["ArenaPower"]["text_format"] = "[manacolor][power:percent]"
E.db["unitframe"]["units"]["arena"]["customTexts"]["ArenaPower"]["xOffset"] = 0
E.db["unitframe"]["units"]["arena"]["customTexts"]["ArenaPower"]["yOffset"] = -36
E.db["unitframe"]["units"]["arena"]["debuffs"]["countFont"] = "NotUI Font light"
E.db["unitframe"]["units"]["arena"]["debuffs"]["perrow"] = 7
E.db["unitframe"]["units"]["arena"]["health"]["text_format"] = ""
E.db["unitframe"]["units"]["arena"]["height"] = 45
E.db["unitframe"]["units"]["arena"]["name"]["text_format"] = ""
E.db["unitframe"]["units"]["arena"]["power"]["height"] = 7
E.db["unitframe"]["units"]["arena"]["power"]["text_format"] = ""
E.db["unitframe"]["units"]["arena"]["width"] = 245
E.db["unitframe"]["units"]["assist"]["buffs"]["countFont"] = "NotUI Font light"
E.db["unitframe"]["units"]["assist"]["debuffs"]["countFont"] = "NotUI Font light"
E.db["unitframe"]["units"]["boss"]["buffs"]["countFont"] = "NotUI Font light"
E.db["unitframe"]["units"]["boss"]["buffs"]["enable"] = false
E.db["unitframe"]["units"]["boss"]["castbar"]["customTextFont"]["enable"] = true
E.db["unitframe"]["units"]["boss"]["castbar"]["customTextFont"]["font"] = "NotUI Font light"
E.db["unitframe"]["units"]["boss"]["castbar"]["customTextFont"]["fontSize"] = 9
E.db["unitframe"]["units"]["boss"]["castbar"]["format"] = "CURRENTMAX"
E.db["unitframe"]["units"]["boss"]["castbar"]["height"] = 15
E.db["unitframe"]["units"]["boss"]["castbar"]["timeToHold"] = 0.4
E.db["unitframe"]["units"]["boss"]["castbar"]["width"] = 104
E.db["unitframe"]["units"]["boss"]["colorOverride"] = "FORCE_ON"

if E.db["unitframe"]["units"]["boss"]["customTexts"] == nil then -- this checks if YourCustomTextName Custom Text exists
			E.db["unitframe"]["units"]["boss"]["customTexts"] = {} -- if not, create its table
end
if E.db["unitframe"]["units"]["boss"]["customTexts"]["BossName"] == nil then -- this checks if YourCustomTextName Custom Text exists
			E.db["unitframe"]["units"]["boss"]["customTexts"]["BossName"] = {} -- if not, create its table
end

E.db["unitframe"]["units"]["boss"]["customTexts"]["BossName"]["attachTextTo"] = "Health"
E.db["unitframe"]["units"]["boss"]["customTexts"]["BossName"]["enable"] = true
E.db["unitframe"]["units"]["boss"]["customTexts"]["BossName"]["font"] = "NotUI Font light"
E.db["unitframe"]["units"]["boss"]["customTexts"]["BossName"]["fontOutline"] = "OUTLINE"
E.db["unitframe"]["units"]["boss"]["customTexts"]["BossName"]["justifyH"] = "RIGHT"
E.db["unitframe"]["units"]["boss"]["customTexts"]["BossName"]["size"] = 14
E.db["unitframe"]["units"]["boss"]["customTexts"]["BossName"]["text_format"] = "[name:abbrev:veryshort]"
E.db["unitframe"]["units"]["boss"]["customTexts"]["BossName"]["xOffset"] = 0
E.db["unitframe"]["units"]["boss"]["customTexts"]["BossName"]["yOffset"] = 15

if E.db["unitframe"]["units"]["boss"]["customTexts"]["hp%"] == nil then -- this checks if YourCustomTextName Custom Text exists
			E.db["unitframe"]["units"]["boss"]["customTexts"]["hp%"] = {} -- if not, create its table
end

E.db["unitframe"]["units"]["boss"]["customTexts"]["hp%"]["attachTextTo"] = "Health"
E.db["unitframe"]["units"]["boss"]["customTexts"]["hp%"]["enable"] = false
E.db["unitframe"]["units"]["boss"]["customTexts"]["hp%"]["font"] = "NotUI Font light"
E.db["unitframe"]["units"]["boss"]["customTexts"]["hp%"]["fontOutline"] = "OUTLINE"
E.db["unitframe"]["units"]["boss"]["customTexts"]["hp%"]["justifyH"] = "RIGHT"
E.db["unitframe"]["units"]["boss"]["customTexts"]["hp%"]["size"] = 15
E.db["unitframe"]["units"]["boss"]["customTexts"]["hp%"]["text_format"] = "[health:percent]"
E.db["unitframe"]["units"]["boss"]["customTexts"]["hp%"]["xOffset"] = 0
E.db["unitframe"]["units"]["boss"]["customTexts"]["hp%"]["yOffset"] = 17

if E.db["unitframe"]["units"]["boss"]["customTexts"]["hpcurrent"] == nil then -- this checks if YourCustomTextName Custom Text exists
			E.db["unitframe"]["units"]["boss"]["customTexts"]["hpcurrent"] = {} -- if not, create its table
end

E.db["unitframe"]["units"]["boss"]["customTexts"]["hpcurrent"]["attachTextTo"] = "Frame"
E.db["unitframe"]["units"]["boss"]["customTexts"]["hpcurrent"]["enable"] = true
E.db["unitframe"]["units"]["boss"]["customTexts"]["hpcurrent"]["font"] = "NotUI Font light"
E.db["unitframe"]["units"]["boss"]["customTexts"]["hpcurrent"]["fontOutline"] = "OUTLINE"
E.db["unitframe"]["units"]["boss"]["customTexts"]["hpcurrent"]["justifyH"] = "LEFT"
E.db["unitframe"]["units"]["boss"]["customTexts"]["hpcurrent"]["size"] = 13
E.db["unitframe"]["units"]["boss"]["customTexts"]["hpcurrent"]["text_format"] = " [health:current:shortvalue] || [health:percent]"
E.db["unitframe"]["units"]["boss"]["customTexts"]["hpcurrent"]["xOffset"] = -5
E.db["unitframe"]["units"]["boss"]["customTexts"]["hpcurrent"]["yOffset"] = -20
E.db["unitframe"]["units"]["boss"]["debuffs"]["anchorPoint"] = "RIGHT"
E.db["unitframe"]["units"]["boss"]["debuffs"]["countFont"] = "NotUI Font light"
E.db["unitframe"]["units"]["boss"]["debuffs"]["countPosition"] = "BOTTOM"
E.db["unitframe"]["units"]["boss"]["debuffs"]["countYOffset"] = -5
E.db["unitframe"]["units"]["boss"]["debuffs"]["sizeOverride"] = 23
E.db["unitframe"]["units"]["boss"]["debuffs"]["spacing"] = -1
E.db["unitframe"]["units"]["boss"]["debuffs"]["yOffset"] = -1
E.db["unitframe"]["units"]["boss"]["disableFocusGlow"] = true
E.db["unitframe"]["units"]["boss"]["disableTargetGlow"] = true
E.db["unitframe"]["units"]["boss"]["growthDirection"] = "UP"
E.db["unitframe"]["units"]["boss"]["health"]["text_format"] = ""
E.db["unitframe"]["units"]["boss"]["height"] = 25
E.db["unitframe"]["units"]["boss"]["name"]["text_format"] = ""
E.db["unitframe"]["units"]["boss"]["power"]["height"] = 5
E.db["unitframe"]["units"]["boss"]["power"]["text_format"] = ""
E.db["unitframe"]["units"]["boss"]["width"] = 150
E.db["unitframe"]["units"]["focus"]["castbar"]["customTextFont"]["enable"] = true
E.db["unitframe"]["units"]["focus"]["castbar"]["customTextFont"]["font"] = "NotUI Font light"
E.db["unitframe"]["units"]["focus"]["castbar"]["customTextFont"]["fontSize"] = 14
E.db["unitframe"]["units"]["focus"]["castbar"]["customTimeFont"]["enable"] = true
E.db["unitframe"]["units"]["focus"]["castbar"]["customTimeFont"]["font"] = "NotUI Font light"
E.db["unitframe"]["units"]["focus"]["castbar"]["customTimeFont"]["fontSize"] = 14
E.db["unitframe"]["units"]["focus"]["castbar"]["timeToHold"] = 0.3
E.db["unitframe"]["units"]["focus"]["colorOverride"] = "FORCE_ON"

if E.db["unitframe"]["units"]["focus"]["customTexts"] == nil then -- this checks if YourCustomTextName Custom Text exists
			E.db["unitframe"]["units"]["focus"]["customTexts"] = {} -- if not, create its table
end

if E.db["unitframe"]["units"]["focus"]["customTexts"]["FocusHealth"] == nil then -- this checks if YourCustomTextName Custom Text exists
			E.db["unitframe"]["units"]["focus"]["customTexts"]["FocusHealth"] = {} -- if not, create its table
end

E.db["unitframe"]["units"]["focus"]["customTexts"]["FocusHealth"]["attachTextTo"] = "Health"
E.db["unitframe"]["units"]["focus"]["customTexts"]["FocusHealth"]["enable"] = true
E.db["unitframe"]["units"]["focus"]["customTexts"]["FocusHealth"]["font"] = "NotUI Font light"
E.db["unitframe"]["units"]["focus"]["customTexts"]["FocusHealth"]["fontOutline"] = "OUTLINE"
E.db["unitframe"]["units"]["focus"]["customTexts"]["FocusHealth"]["justifyH"] = "RIGHT"
E.db["unitframe"]["units"]["focus"]["customTexts"]["FocusHealth"]["size"] = 15
E.db["unitframe"]["units"]["focus"]["customTexts"]["FocusHealth"]["text_format"] = "[health:percent]"
E.db["unitframe"]["units"]["focus"]["customTexts"]["FocusHealth"]["xOffset"] = 0
E.db["unitframe"]["units"]["focus"]["customTexts"]["FocusHealth"]["yOffset"] = 14

if E.db["unitframe"]["units"]["focus"]["customTexts"]["FocusName"] == nil then -- this checks if YourCustomTextName Custom Text exists
			E.db["unitframe"]["units"]["focus"]["customTexts"]["FocusName"] = {} -- if not, create its table
end

E.db["unitframe"]["units"]["focus"]["customTexts"]["FocusName"]["attachTextTo"] = "Health"
E.db["unitframe"]["units"]["focus"]["customTexts"]["FocusName"]["enable"] = true
E.db["unitframe"]["units"]["focus"]["customTexts"]["FocusName"]["font"] = "NotUI Font light"
E.db["unitframe"]["units"]["focus"]["customTexts"]["FocusName"]["fontOutline"] = "OUTLINE"
E.db["unitframe"]["units"]["focus"]["customTexts"]["FocusName"]["justifyH"] = "LEFT"
E.db["unitframe"]["units"]["focus"]["customTexts"]["FocusName"]["size"] = 16
E.db["unitframe"]["units"]["focus"]["customTexts"]["FocusName"]["text_format"] = "[name:abbrev]"
E.db["unitframe"]["units"]["focus"]["customTexts"]["FocusName"]["xOffset"] = 0
E.db["unitframe"]["units"]["focus"]["customTexts"]["FocusName"]["yOffset"] = 14
E.db["unitframe"]["units"]["focus"]["debuffs"]["enable"] = false
E.db["unitframe"]["units"]["focus"]["disableMouseoverGlow"] = true
E.db["unitframe"]["units"]["focus"]["disableTargetGlow"] = true
E.db["unitframe"]["units"]["focus"]["height"] = 28
E.db["unitframe"]["units"]["focus"]["name"]["text_format"] = ""
E.db["unitframe"]["units"]["focus"]["power"]["height"] = 5
E.db["unitframe"]["units"]["party"]["ROLE1"] = "HEALER"
E.db["unitframe"]["units"]["party"]["ROLE2"] = "TANK"
E.db["unitframe"]["units"]["party"]["buffIndicator"]["size"] = 16
E.db["unitframe"]["units"]["party"]["buffs"]["anchorPoint"] = "TOPRIGHT"
E.db["unitframe"]["units"]["party"]["buffs"]["attachTo"] = "HEALTH"
E.db["unitframe"]["units"]["party"]["buffs"]["countFont"] = "NotUI Font light"
E.db["unitframe"]["units"]["party"]["buffs"]["countPosition"] = "BOTTOM"
E.db["unitframe"]["units"]["party"]["buffs"]["countYOffset"] = -5
E.db["unitframe"]["units"]["party"]["buffs"]["durationPosition"] = "TOPRIGHT"
E.db["unitframe"]["units"]["party"]["buffs"]["growthX"] = "LEFT"
E.db["unitframe"]["units"]["party"]["buffs"]["perrow"] = 5
E.db["unitframe"]["units"]["party"]["buffs"]["sizeOverride"] = 21
E.db["unitframe"]["units"]["party"]["buffs"]["spacing"] = 0
E.db["unitframe"]["units"]["party"]["buffs"]["yOffset"] = -11
E.db["unitframe"]["units"]["party"]["castbar"]["width"] = 117
E.db["unitframe"]["units"]["party"]["colorOverride"] = "FORCE_ON"

if E.db["unitframe"]["units"]["party"]["customTexts"] == nil then -- this checks if YourCustomTextName Custom Text exists
			E.db["unitframe"]["units"]["party"]["customTexts"] = {} -- if not, create its table
end
if E.db["unitframe"]["units"]["party"]["customTexts"]["health1"] == nil then -- this checks if YourCustomTextName Custom Text exists
			E.db["unitframe"]["units"]["party"]["customTexts"]["health1"] = {} -- if not, create its table
end

E.db["unitframe"]["units"]["party"]["customTexts"]["health1"]["attachTextTo"] = "Health"
E.db["unitframe"]["units"]["party"]["customTexts"]["health1"]["enable"] = false
E.db["unitframe"]["units"]["party"]["customTexts"]["health1"]["font"] = "NotUI Font light"
E.db["unitframe"]["units"]["party"]["customTexts"]["health1"]["fontOutline"] = "OUTLINE"
E.db["unitframe"]["units"]["party"]["customTexts"]["health1"]["justifyH"] = "LEFT"
E.db["unitframe"]["units"]["party"]["customTexts"]["health1"]["size"] = 15
E.db["unitframe"]["units"]["party"]["customTexts"]["health1"]["text_format"] = "[health:current] || [health:percent]"
E.db["unitframe"]["units"]["party"]["customTexts"]["health1"]["xOffset"] = 0
E.db["unitframe"]["units"]["party"]["customTexts"]["health1"]["yOffset"] = 3

if E.db["unitframe"]["units"]["party"]["customTexts"]["name1"] == nil then -- this checks if YourCustomTextName Custom Text exists
			E.db["unitframe"]["units"]["party"]["customTexts"]["name1"] = {} -- if not, create its table
end

E.db["unitframe"]["units"]["party"]["customTexts"]["name1"]["attachTextTo"] = "Health"
E.db["unitframe"]["units"]["party"]["customTexts"]["name1"]["enable"] = true
E.db["unitframe"]["units"]["party"]["customTexts"]["name1"]["font"] = "NotUI Font light"
E.db["unitframe"]["units"]["party"]["customTexts"]["name1"]["fontOutline"] = "OUTLINE"
E.db["unitframe"]["units"]["party"]["customTexts"]["name1"]["justifyH"] = "LEFT"
E.db["unitframe"]["units"]["party"]["customTexts"]["name1"]["size"] = 14
E.db["unitframe"]["units"]["party"]["customTexts"]["name1"]["text_format"] = "[name:veryshort] [difficultycolor][smartlevel]"
E.db["unitframe"]["units"]["party"]["customTexts"]["name1"]["xOffset"] = 0
E.db["unitframe"]["units"]["party"]["customTexts"]["name1"]["yOffset"] = 15
E.db["unitframe"]["units"]["party"]["debuffs"]["countFont"] = "NotUI Font light"
E.db["unitframe"]["units"]["party"]["debuffs"]["countFontSize"] = 14
E.db["unitframe"]["units"]["party"]["debuffs"]["countPosition"] = "BOTTOM"
E.db["unitframe"]["units"]["party"]["debuffs"]["countYOffset"] = -8
E.db["unitframe"]["units"]["party"]["debuffs"]["perrow"] = 6
E.db["unitframe"]["units"]["party"]["debuffs"]["priority"] = "ssl,Dispellable,Blacklist,Boss,RaidDebuffs,CCDebuffs,Whitelist"
E.db["unitframe"]["units"]["party"]["debuffs"]["sizeOverride"] = 30
E.db["unitframe"]["units"]["party"]["debuffs"]["spacing"] = 0
E.db["unitframe"]["units"]["party"]["debuffs"]["yOffset"] = -1
E.db["unitframe"]["units"]["party"]["fader"]["minAlpha"] = 0.5
E.db["unitframe"]["units"]["party"]["groupBy"] = "ROLE"
E.db["unitframe"]["units"]["party"]["healPrediction"]["enable"] = true
E.db["unitframe"]["units"]["party"]["health"]["text_format"] = ""
E.db["unitframe"]["units"]["party"]["height"] = 35
E.db["unitframe"]["units"]["party"]["horizontalSpacing"] = -1
E.db["unitframe"]["units"]["party"]["name"]["text_format"] = ""
E.db["unitframe"]["units"]["party"]["petsGroup"]["width"] = 67
E.db["unitframe"]["units"]["party"]["petsGroup"]["xOffset"] = 0
E.db["unitframe"]["units"]["party"]["petsGroup"]["yOffset"] = -31
E.db["unitframe"]["units"]["party"]["power"]["enable"] = false
E.db["unitframe"]["units"]["party"]["power"]["height"] = 4
E.db["unitframe"]["units"]["party"]["power"]["text_format"] = ""
E.db["unitframe"]["units"]["party"]["raidRoleIcons"]["position"] = "TOPRIGHT"
E.db["unitframe"]["units"]["party"]["raidRoleIcons"]["yOffset"] = 5
E.db["unitframe"]["units"]["party"]["raidicon"]["size"] = 25
E.db["unitframe"]["units"]["party"]["raidicon"]["yOffset"] = -4
E.db["unitframe"]["units"]["party"]["rdebuffs"]["enable"] = false
E.db["unitframe"]["units"]["party"]["rdebuffs"]["font"] = "NotUI Font light"
E.db["unitframe"]["units"]["party"]["showPlayer"] = false
E.db["unitframe"]["units"]["party"]["verticalSpacing"] = 11
E.db["unitframe"]["units"]["party"]["width"] = 180
E.db["unitframe"]["units"]["pet"]["buffs"]["countFont"] = "NotUI Font light"
E.db["unitframe"]["units"]["pet"]["castbar"]["overlayOnFrame"] = "InfoPanel"
E.db["unitframe"]["units"]["pet"]["castbar"]["width"] = 130
E.db["unitframe"]["units"]["pet"]["colorOverride"] = "FORCE_ON"

if E.db["unitframe"]["units"]["pet"]["customTexts"] == nil then -- this checks if YourCustomTextName Custom Text exists
			E.db["unitframe"]["units"]["pet"]["customTexts"] = {} -- if not, create its table
end
if E.db["unitframe"]["units"]["pet"]["customTexts"]["PetName"] == nil then -- this checks if YourCustomTextName Custom Text exists
			E.db["unitframe"]["units"]["pet"]["customTexts"]["PetName"] = {} -- if not, create its table
end

E.db["unitframe"]["units"]["pet"]["customTexts"]["PetName"]["attachTextTo"] = "Health"
E.db["unitframe"]["units"]["pet"]["customTexts"]["PetName"]["enable"] = true
E.db["unitframe"]["units"]["pet"]["customTexts"]["PetName"]["font"] = "NotUI Font light"
E.db["unitframe"]["units"]["pet"]["customTexts"]["PetName"]["fontOutline"] = "OUTLINE"
E.db["unitframe"]["units"]["pet"]["customTexts"]["PetName"]["justifyH"] = "CENTER"
E.db["unitframe"]["units"]["pet"]["customTexts"]["PetName"]["size"] = 14
E.db["unitframe"]["units"]["pet"]["customTexts"]["PetName"]["text_format"] = "[name:short]"
E.db["unitframe"]["units"]["pet"]["customTexts"]["PetName"]["xOffset"] = 0
E.db["unitframe"]["units"]["pet"]["customTexts"]["PetName"]["yOffset"] = 0
E.db["unitframe"]["units"]["pet"]["debuffs"]["countFont"] = "NotUI Font light"
E.db["unitframe"]["units"]["pet"]["name"]["text_format"] = ""
E.db["unitframe"]["units"]["pet"]["power"]["enable"] = false
E.db["unitframe"]["units"]["player"]["CombatIcon"]["size"] = 15
E.db["unitframe"]["units"]["player"]["CombatIcon"]["texture"] = "ATTACK"
E.db["unitframe"]["units"]["player"]["aurabar"]["anchorPoint"] = "BELOW"
E.db["unitframe"]["units"]["player"]["aurabar"]["attachTo"] = "FRAME"
E.db["unitframe"]["units"]["player"]["aurabar"]["enable"] = false
E.db["unitframe"]["units"]["player"]["aurabar"]["height"] = 12
E.db["unitframe"]["units"]["player"]["aurabar"]["maxBars"] = 5
E.db["unitframe"]["units"]["player"]["buffs"]["anchorPoint"] = "TOPRIGHT"
E.db["unitframe"]["units"]["player"]["buffs"]["attachTo"] = "FRAME"
E.db["unitframe"]["units"]["player"]["buffs"]["countFont"] = "NotUI Font light"
E.db["unitframe"]["units"]["player"]["buffs"]["countFontSize"] = 15
E.db["unitframe"]["units"]["player"]["buffs"]["countPosition"] = "TOP"
E.db["unitframe"]["units"]["player"]["buffs"]["countYOffset"] = 9
E.db["unitframe"]["units"]["player"]["buffs"]["growthX"] = "LEFT"
E.db["unitframe"]["units"]["player"]["buffs"]["perrow"] = 5
E.db["unitframe"]["units"]["player"]["buffs"]["priority"] = "DK BUFFS"
E.db["unitframe"]["units"]["player"]["buffs"]["sizeOverride"] = 35
E.db["unitframe"]["units"]["player"]["buffs"]["sortDirection"] = "ASCENDING"
E.db["unitframe"]["units"]["player"]["castbar"]["customColor"]["enable"] = true
E.db["unitframe"]["units"]["player"]["castbar"]["customColor"]["useClassColor"] = true
E.db["unitframe"]["units"]["player"]["castbar"]["customTextFont"]["enable"] = true
E.db["unitframe"]["units"]["player"]["castbar"]["customTextFont"]["font"] = "NotUI Font light"
E.db["unitframe"]["units"]["player"]["castbar"]["customTextFont"]["fontSize"] = 15
E.db["unitframe"]["units"]["player"]["castbar"]["customTimeFont"]["enable"] = true
E.db["unitframe"]["units"]["player"]["castbar"]["customTimeFont"]["font"] = "NotUI Font light"
E.db["unitframe"]["units"]["player"]["castbar"]["customTimeFont"]["fontSize"] = 15
E.db["unitframe"]["units"]["player"]["castbar"]["enable"] = false
E.db["unitframe"]["units"]["player"]["castbar"]["height"] = 25
E.db["unitframe"]["units"]["player"]["castbar"]["textColor"]["b"] = 0.65098041296005
E.db["unitframe"]["units"]["player"]["castbar"]["textColor"]["g"] = 0.74901962280273
E.db["unitframe"]["units"]["player"]["castbar"]["textColor"]["r"] = 0.83921575546265
E.db["unitframe"]["units"]["player"]["castbar"]["width"] = 290
E.db["unitframe"]["units"]["player"]["classbar"]["enable"] = false
E.db["unitframe"]["units"]["player"]["colorOverride"] = "FORCE_ON"

if E.db["unitframe"]["units"]["player"]["customTexts"] == nil then -- this checks if YourCustomTextName Custom Text exists
			E.db["unitframe"]["units"]["player"]["customTexts"] = {} -- if not, create its table
end
if E.db["unitframe"]["units"]["player"]["customTexts"]["Shield info"] == nil then -- this checks if YourCustomTextName Custom Text exists
			E.db["unitframe"]["units"]["player"]["customTexts"]["Shield info"] = {} -- if not, create its table
end

E.db["unitframe"]["units"]["player"]["customTexts"]["Shield info"]["attachTextTo"] = "Health"
E.db["unitframe"]["units"]["player"]["customTexts"]["Shield info"]["enable"] = true
E.db["unitframe"]["units"]["player"]["customTexts"]["Shield info"]["font"] = "NotUI Font light"
E.db["unitframe"]["units"]["player"]["customTexts"]["Shield info"]["fontOutline"] = "OUTLINE"
E.db["unitframe"]["units"]["player"]["customTexts"]["Shield info"]["justifyH"] = "RIGHT"
E.db["unitframe"]["units"]["player"]["customTexts"]["Shield info"]["size"] = 16
E.db["unitframe"]["units"]["player"]["customTexts"]["Shield info"]["text_format"] = "[absorbs]"
E.db["unitframe"]["units"]["player"]["customTexts"]["Shield info"]["xOffset"] = 0
E.db["unitframe"]["units"]["player"]["customTexts"]["Shield info"]["yOffset"] = 0

if E.db["unitframe"]["units"]["player"]["customTexts"]["[name]"] == nil then -- this checks if YourCustomTextName Custom Text exists
			E.db["unitframe"]["units"]["player"]["customTexts"]["[name]"] = {} -- if not, create its table
end

E.db["unitframe"]["units"]["player"]["customTexts"]["[name]"]["attachTextTo"] = "Health"
E.db["unitframe"]["units"]["player"]["customTexts"]["[name]"]["enable"] = true
E.db["unitframe"]["units"]["player"]["customTexts"]["[name]"]["font"] = "NotUI Font light"
E.db["unitframe"]["units"]["player"]["customTexts"]["[name]"]["fontOutline"] = "OUTLINE"
E.db["unitframe"]["units"]["player"]["customTexts"]["[name]"]["justifyH"] = "LEFT"
E.db["unitframe"]["units"]["player"]["customTexts"]["[name]"]["size"] = 18
E.db["unitframe"]["units"]["player"]["customTexts"]["[name]"]["text_format"] = "[name:medium]"
E.db["unitframe"]["units"]["player"]["customTexts"]["[name]"]["xOffset"] = 0
E.db["unitframe"]["units"]["player"]["customTexts"]["[name]"]["yOffset"] = 16

if E.db["unitframe"]["units"]["player"]["customTexts"]["health info"] == nil then -- this checks if YourCustomTextName Custom Text exists
			E.db["unitframe"]["units"]["player"]["customTexts"]["health info"] = {} -- if not, create its table
end

E.db["unitframe"]["units"]["player"]["customTexts"]["health info"]["attachTextTo"] = "Frame"
E.db["unitframe"]["units"]["player"]["customTexts"]["health info"]["enable"] = true
E.db["unitframe"]["units"]["player"]["customTexts"]["health info"]["font"] = "NotUI Font light"
E.db["unitframe"]["units"]["player"]["customTexts"]["health info"]["fontOutline"] = "OUTLINE"
E.db["unitframe"]["units"]["player"]["customTexts"]["health info"]["justifyH"] = "RIGHT"
E.db["unitframe"]["units"]["player"]["customTexts"]["health info"]["size"] = 16
E.db["unitframe"]["units"]["player"]["customTexts"]["health info"]["text_format"] = "[health:percent] || [health:current:shortvalue]"
E.db["unitframe"]["units"]["player"]["customTexts"]["health info"]["xOffset"] = 0
E.db["unitframe"]["units"]["player"]["customTexts"]["health info"]["yOffset"] = -23
E.db["unitframe"]["units"]["player"]["debuffs"]["countFont"] = "NotUI Font light"
E.db["unitframe"]["units"]["player"]["debuffs"]["enable"] = false
E.db["unitframe"]["units"]["player"]["debuffs"]["numrows"] = 4
E.db["unitframe"]["units"]["player"]["debuffs"]["perrow"] = 3
E.db["unitframe"]["units"]["player"]["debuffs"]["sizeOverride"] = 35
E.db["unitframe"]["units"]["player"]["health"]["text_format"] = ""
E.db["unitframe"]["units"]["player"]["health"]["xOffset"] = 204
E.db["unitframe"]["units"]["player"]["health"]["yOffset"] = -21
E.db["unitframe"]["units"]["player"]["height"] = 28
E.db["unitframe"]["units"]["player"]["name"]["attachTextTo"] = "Frame"
E.db["unitframe"]["units"]["player"]["name"]["xOffset"] = -100
E.db["unitframe"]["units"]["player"]["name"]["yOffset"] = 30
E.db["unitframe"]["units"]["player"]["power"]["enable"] = false
E.db["unitframe"]["units"]["player"]["raidRoleIcons"]["yOffset"] = 11
E.db["unitframe"]["units"]["player"]["width"] = 280
E.db["unitframe"]["units"]["raid1"]["buffs"]["countFont"] = "NotUI Font light"
E.db["unitframe"]["units"]["raid1"]["colorOverride"] = "FORCE_ON"

if E.db["unitframe"]["units"]["raid1"]["customTexts"] == nil then -- this checks if YourCustomTextName Custom Text exists
			E.db["unitframe"]["units"]["raid1"]["customTexts"] = {} -- if not, create its table
end
if E.db["unitframe"]["units"]["raid1"]["customTexts"]["RaidName"] == nil then -- this checks if YourCustomTextName Custom Text exists
			E.db["unitframe"]["units"]["raid1"]["customTexts"]["RaidName"] = {} -- if not, create its table
end

E.db["unitframe"]["units"]["raid1"]["customTexts"]["RaidName"]["attachTextTo"] = "Health"
E.db["unitframe"]["units"]["raid1"]["customTexts"]["RaidName"]["enable"] = true
E.db["unitframe"]["units"]["raid1"]["customTexts"]["RaidName"]["font"] = "NotUI Font light"
E.db["unitframe"]["units"]["raid1"]["customTexts"]["RaidName"]["fontOutline"] = "OUTLINE"
E.db["unitframe"]["units"]["raid1"]["customTexts"]["RaidName"]["justifyH"] = "CENTER"
E.db["unitframe"]["units"]["raid1"]["customTexts"]["RaidName"]["size"] = 12
E.db["unitframe"]["units"]["raid1"]["customTexts"]["RaidName"]["text_format"] = "[name:short]"
E.db["unitframe"]["units"]["raid1"]["customTexts"]["RaidName"]["xOffset"] = 0
E.db["unitframe"]["units"]["raid1"]["customTexts"]["RaidName"]["yOffset"] = 0
E.db["unitframe"]["units"]["raid1"]["debuffs"]["countFont"] = "NotUI Font light"
E.db["unitframe"]["units"]["raid1"]["health"]["text_format"] = ""
E.db["unitframe"]["units"]["raid1"]["height"] = 35
E.db["unitframe"]["units"]["raid1"]["horizontalSpacing"] = 1
E.db["unitframe"]["units"]["raid1"]["name"]["text_format"] = ""
E.db["unitframe"]["units"]["raid1"]["numGroups"] = 8
E.db["unitframe"]["units"]["raid1"]["power"]["enable"] = false
E.db["unitframe"]["units"]["raid1"]["raidRoleIcons"]["yOffset"] = 5
E.db["unitframe"]["units"]["raid1"]["rdebuffs"]["font"] = "NotUI Font light"
E.db["unitframe"]["units"]["raid1"]["verticalSpacing"] = 1
E.db["unitframe"]["units"]["raid1"]["width"] = 90
E.db["unitframe"]["units"]["raid2"]["rdebuffs"]["font"] = "NotUI Font light"
E.db["unitframe"]["units"]["raid3"]["colorOverride"] = "FORCE_ON"
E.db["unitframe"]["units"]["raid3"]["height"] = 35
E.db["unitframe"]["units"]["raid3"]["horizontalSpacing"] = 1
E.db["unitframe"]["units"]["raid3"]["rdebuffs"]["font"] = "NotUI Font light"
E.db["unitframe"]["units"]["raid3"]["roleIcon"]["enable"] = true
E.db["unitframe"]["units"]["raid3"]["verticalSpacing"] = 1
E.db["unitframe"]["units"]["raid3"]["width"] = 90
E.db["unitframe"]["units"]["tank"]["buffs"]["countFont"] = "NotUI Font light"
E.db["unitframe"]["units"]["tank"]["debuffs"]["countFont"] = "NotUI Font light"
E.db["unitframe"]["units"]["tank"]["disableFocusGlow"] = true
E.db["unitframe"]["units"]["tank"]["disableTargetGlow"] = true
E.db["unitframe"]["units"]["tank"]["name"]["text_format"] = "[name:medium]"
E.db["unitframe"]["units"]["tank"]["rdebuffs"]["font"] = "ITC Avant Garde Gothic Medium"
E.db["unitframe"]["units"]["tank"]["targetsGroup"]["enable"] = false
E.db["unitframe"]["units"]["tank"]["verticalSpacing"] = 1
E.db["unitframe"]["units"]["tank"]["width"] = 90
E.db["unitframe"]["units"]["target"]["aurabar"]["anchorPoint"] = "BELOW"
E.db["unitframe"]["units"]["target"]["aurabar"]["attachTo"] = "FRAME"
E.db["unitframe"]["units"]["target"]["aurabar"]["enable"] = false
E.db["unitframe"]["units"]["target"]["aurabar"]["height"] = 12
E.db["unitframe"]["units"]["target"]["aurabar"]["maxBars"] = 5
E.db["unitframe"]["units"]["target"]["buffs"]["countFont"] = "NotUI Font light"
E.db["unitframe"]["units"]["target"]["buffs"]["numrows"] = 3
E.db["unitframe"]["units"]["target"]["buffs"]["perrow"] = 4
E.db["unitframe"]["units"]["target"]["buffs"]["sizeOverride"] = 25
E.db["unitframe"]["units"]["target"]["buffs"]["spacing"] = 0
E.db["unitframe"]["units"]["target"]["buffs"]["yOffset"] = 10
E.db["unitframe"]["units"]["target"]["castbar"]["customTextFont"]["enable"] = true
E.db["unitframe"]["units"]["target"]["castbar"]["customTextFont"]["font"] = "NotUI Font light"
E.db["unitframe"]["units"]["target"]["castbar"]["customTextFont"]["fontSize"] = 14
E.db["unitframe"]["units"]["target"]["castbar"]["customTimeFont"]["enable"] = true
E.db["unitframe"]["units"]["target"]["castbar"]["customTimeFont"]["font"] = "NotUI Font light"
E.db["unitframe"]["units"]["target"]["castbar"]["customTimeFont"]["fontSize"] = 14
E.db["unitframe"]["units"]["target"]["castbar"]["icon"] = false
E.db["unitframe"]["units"]["target"]["castbar"]["overlayOnFrame"] = "Health"
E.db["unitframe"]["units"]["target"]["castbar"]["width"] = 280
E.db["unitframe"]["units"]["target"]["colorOverride"] = "FORCE_ON"

if E.db["unitframe"]["units"]["target"]["customTexts"] == nil then -- this checks if YourCustomTextName Custom Text exists
			E.db["unitframe"]["units"]["target"]["customTexts"] = {} -- if not, create its table
end
if E.db["unitframe"]["units"]["target"]["customTexts"]["absorb"] == nil then -- this checks if YourCustomTextName Custom Text exists
			E.db["unitframe"]["units"]["target"]["customTexts"]["absorb"] = {} -- if not, create its table
end

E.db["unitframe"]["units"]["target"]["customTexts"]["absorb"]["attachTextTo"] = "Health"
E.db["unitframe"]["units"]["target"]["customTexts"]["absorb"]["enable"] = true
E.db["unitframe"]["units"]["target"]["customTexts"]["absorb"]["font"] = "NotUI Font light"
E.db["unitframe"]["units"]["target"]["customTexts"]["absorb"]["fontOutline"] = "OUTLINE"
E.db["unitframe"]["units"]["target"]["customTexts"]["absorb"]["justifyH"] = "LEFT"
E.db["unitframe"]["units"]["target"]["customTexts"]["absorb"]["size"] = 16
E.db["unitframe"]["units"]["target"]["customTexts"]["absorb"]["text_format"] = "[absorbs]"
E.db["unitframe"]["units"]["target"]["customTexts"]["absorb"]["xOffset"] = 0
E.db["unitframe"]["units"]["target"]["customTexts"]["absorb"]["yOffset"] = 0

if E.db["unitframe"]["units"]["target"]["customTexts"]["health1"] == nil then -- this checks if YourCustomTextName Custom Text exists
			E.db["unitframe"]["units"]["target"]["customTexts"]["health1"] = {} -- if not, create its table
end

E.db["unitframe"]["units"]["target"]["customTexts"]["health1"]["attachTextTo"] = "Frame"
E.db["unitframe"]["units"]["target"]["customTexts"]["health1"]["enable"] = true
E.db["unitframe"]["units"]["target"]["customTexts"]["health1"]["font"] = "NotUI Font light"
E.db["unitframe"]["units"]["target"]["customTexts"]["health1"]["fontOutline"] = "OUTLINE"
E.db["unitframe"]["units"]["target"]["customTexts"]["health1"]["justifyH"] = "LEFT"
E.db["unitframe"]["units"]["target"]["customTexts"]["health1"]["size"] = 16
E.db["unitframe"]["units"]["target"]["customTexts"]["health1"]["text_format"] = "[health:current:shortvalue]|| [health:percent]"
E.db["unitframe"]["units"]["target"]["customTexts"]["health1"]["xOffset"] = 0
E.db["unitframe"]["units"]["target"]["customTexts"]["health1"]["yOffset"] = -22

if E.db["unitframe"]["units"]["target"]["customTexts"]["name1"] == nil then -- this checks if YourCustomTextName Custom Text exists
			E.db["unitframe"]["units"]["target"]["customTexts"]["name1"] = {} -- if not, create its table
end

E.db["unitframe"]["units"]["target"]["customTexts"]["name1"]["attachTextTo"] = "Health"
E.db["unitframe"]["units"]["target"]["customTexts"]["name1"]["enable"] = true
E.db["unitframe"]["units"]["target"]["customTexts"]["name1"]["font"] = "NotUI Font light"
E.db["unitframe"]["units"]["target"]["customTexts"]["name1"]["fontOutline"] = "OUTLINE"
E.db["unitframe"]["units"]["target"]["customTexts"]["name1"]["justifyH"] = "RIGHT"
E.db["unitframe"]["units"]["target"]["customTexts"]["name1"]["size"] = 17
E.db["unitframe"]["units"]["target"]["customTexts"]["name1"]["text_format"] = "[name:abbrev]"
E.db["unitframe"]["units"]["target"]["customTexts"]["name1"]["xOffset"] = 0
E.db["unitframe"]["units"]["target"]["customTexts"]["name1"]["yOffset"] = 15

if E.db["unitframe"]["units"]["target"]["customTexts"]["power1"] == nil then -- this checks if YourCustomTextName Custom Text exists
			E.db["unitframe"]["units"]["target"]["customTexts"]["power1"] = {} -- if not, create its table
end

E.db["unitframe"]["units"]["target"]["customTexts"]["power1"]["attachTextTo"] = "Health"
E.db["unitframe"]["units"]["target"]["customTexts"]["power1"]["enable"] = true
E.db["unitframe"]["units"]["target"]["customTexts"]["power1"]["font"] = "NotUI Font light"
E.db["unitframe"]["units"]["target"]["customTexts"]["power1"]["fontOutline"] = "OUTLINE"
E.db["unitframe"]["units"]["target"]["customTexts"]["power1"]["justifyH"] = "RIGHT"
E.db["unitframe"]["units"]["target"]["customTexts"]["power1"]["size"] = 13
E.db["unitframe"]["units"]["target"]["customTexts"]["power1"]["text_format"] = "[classpowercolor][power:percent]"
E.db["unitframe"]["units"]["target"]["customTexts"]["power1"]["xOffset"] = 0
E.db["unitframe"]["units"]["target"]["customTexts"]["power1"]["yOffset"] = -22
E.db["unitframe"]["units"]["target"]["debuffs"]["anchorPoint"] = "TOPLEFT"
E.db["unitframe"]["units"]["target"]["debuffs"]["attachTo"] = "FRAME"
E.db["unitframe"]["units"]["target"]["debuffs"]["countFont"] = "NotUI Font light"
E.db["unitframe"]["units"]["target"]["debuffs"]["growthX"] = "RIGHT"
E.db["unitframe"]["units"]["target"]["debuffs"]["numrows"] = 3
E.db["unitframe"]["units"]["target"]["debuffs"]["perrow"] = 4
E.db["unitframe"]["units"]["target"]["debuffs"]["sizeOverride"] = 25
E.db["unitframe"]["units"]["target"]["debuffs"]["spacing"] = 0
E.db["unitframe"]["units"]["target"]["debuffs"]["yOffset"] = 10
E.db["unitframe"]["units"]["target"]["health"]["text_format"] = ""
E.db["unitframe"]["units"]["target"]["height"] = 28
E.db["unitframe"]["units"]["target"]["name"]["text_format"] = ""
E.db["unitframe"]["units"]["target"]["power"]["attachTextTo"] = "Frame"
E.db["unitframe"]["units"]["target"]["power"]["height"] = 5
E.db["unitframe"]["units"]["target"]["power"]["strataAndLevel"]["frameLevel"] = 2
E.db["unitframe"]["units"]["target"]["power"]["text_format"] = ""
E.db["unitframe"]["units"]["target"]["power"]["yOffset"] = 6
E.db["unitframe"]["units"]["target"]["width"] = 280
E.db["unitframe"]["units"]["targettarget"]["colorOverride"] = "FORCE_ON"

if E.db["unitframe"]["units"]["targettarget"]["customTexts"] == nil then -- this checks if YourCustomTextName Custom Text exists
			E.db["unitframe"]["units"]["targettarget"]["customTexts"] = {} -- if not, create its table
end
if E.db["unitframe"]["units"]["targettarget"]["customTexts"]["name1"] == nil then -- this checks if YourCustomTextName Custom Text exists
			E.db["unitframe"]["units"]["targettarget"]["customTexts"]["name1"] = {} -- if not, create its table
end

E.db["unitframe"]["units"]["targettarget"]["customTexts"]["name1"]["attachTextTo"] = "Frame"
E.db["unitframe"]["units"]["targettarget"]["customTexts"]["name1"]["enable"] = true
E.db["unitframe"]["units"]["targettarget"]["customTexts"]["name1"]["font"] = "NotUI Font light"
E.db["unitframe"]["units"]["targettarget"]["customTexts"]["name1"]["fontOutline"] = "OUTLINE"
E.db["unitframe"]["units"]["targettarget"]["customTexts"]["name1"]["justifyH"] = "RIGHT"
E.db["unitframe"]["units"]["targettarget"]["customTexts"]["name1"]["size"] = 13
E.db["unitframe"]["units"]["targettarget"]["customTexts"]["name1"]["text_format"] = "[name:abbrev]"
E.db["unitframe"]["units"]["targettarget"]["customTexts"]["name1"]["xOffset"] = 0
E.db["unitframe"]["units"]["targettarget"]["customTexts"]["name1"]["yOffset"] = 10
E.db["unitframe"]["units"]["targettarget"]["debuffs"]["enable"] = false
E.db["unitframe"]["units"]["targettarget"]["height"] = 19
E.db["unitframe"]["units"]["targettarget"]["name"]["text_format"] = ""
E.db["unitframe"]["units"]["targettarget"]["power"]["enable"] = false


E.private["general"]["dmgfont"] = "NotUI Font Heavy"
E.private["general"]["namefont"] = "NotUI Font light"
E.private["general"]["nameplateFont"] = "NotUI Font light"
E.private["general"]["nameplateLargeFont"] = "NotUI Font light"
E.private["nameplates"]["enable"] = false

end

--This function will hold your layout settings
local function SetupLayout(layout)
	--[[
	--	PUT YOUR EXPORTED PROFILE/SETTINGS BELOW HERE
	--]]


	--LAYOUT GOES HERE
if layout == "tank" then
	DPSTANK()

elseif layout == "dps" then

	DPSTANK()


end




	--[[
		--If you want to modify the base layout according to
		-- certain conditions then this is how you could do it
		if layout == "tank" then
			--Make some changes to the layout posted above
		elseif layout == "dps" then
			--Make some other changes
		elseif layout == "healer" then
			--Make some different changes
		end
	--]]


	--[[
	--	This section at the bottom is just to update ElvUI and display a message
	--]]
	--Update ElvUI
	E:UpdateAll(true)
	--Show message about layout being set
	PluginInstallStepComplete.message = "Layout Set"
	PluginInstallStepComplete:Show()
end

--This function is executed when you press "Skip Process" or "Finished" in the installer.
local function InstallComplete()
	if GetCVarBool("Sound_EnableMusic") then
		StopMusic()
	end

	--Set a variable tracking the version of the addon when layout was installed
	E.db[MyPluginName].install_version = Version

	ReloadUI()
end

--This is the data we pass on to the ElvUI Plugin Installer.
--The Plugin Installer is reponsible for displaying the install guide for this layout.
local InstallerData = {
	Title = format("|cff4beb2c%s %s|r", MyPluginName, "Installation"),
	Name = MyPluginName,
	--tutorialImage = "Interface\\AddOns\\MyAddOn\\logo.tga", --If you have a logo you want to use, otherwise it uses the one from ElvUI
	Pages = {
		[1] = function()
			PluginInstallFrame.SubTitle:SetFormattedText("Welcome to the installation for %s.", MyPluginName)
			PluginInstallFrame.Desc1:SetText("This installation process will guide you through a few steps and apply settings to your current ElvUI profile. If you want to be able to go back to your original settings then create a new profile before going through this installation process.")
			PluginInstallFrame.Desc2:SetText("Please press the continue button if you wish to go through the installation process, otherwise click the 'Skip Process' button.")
			PluginInstallFrame.Option1:Show()
			PluginInstallFrame.Option1:SetScript("OnClick", InstallComplete)
			PluginInstallFrame.Option1:SetText("Skip Process")
		end,
		[2] = function()
			PluginInstallFrame.SubTitle:SetText("Layouts")
			PluginInstallFrame.Desc1:SetText("These are the layouts that are available. Please click a button below to apply the layout of your choosing.")
			PluginInstallFrame.Desc2:SetText("Importance: |cff07D400High|r")
			PluginInstallFrame.Option1:Show()
			PluginInstallFrame.Option1:SetScript("OnClick", function() SetupLayout("tank") end)
			PluginInstallFrame.Option1:SetText("Tank")
			--PluginInstallFrame.Option2:Show()
			--PluginInstallFrame.Option2:SetScript("OnClick", function() SetupLayout("healer") end)
			--PluginInstallFrame.Option2:SetText("Healer")
		    PluginInstallFrame.Option2:Show()
			PluginInstallFrame.Option2:SetScript("OnClick", function() SetupLayout("dps") end)
			PluginInstallFrame.Option2:SetText("DPS")
		end,
		[3] = function()
			PluginInstallFrame.SubTitle:SetText("Details! profile installation")
			PluginInstallFrame.Desc1:SetText("This is Your profile import string for \"Details!\" addon. If you dont want this just click \"Thanks\" button!")
			PluginInstallFrame.Option1:Show()
			PluginInstallFrame.Option1:SetScript("OnClick", DetailsImportString)
			PluginInstallFrame.Option1:SetText("Details! import string")
		end,
		[4] = function()
			PluginInstallFrame.SubTitle:SetText("Installation Complete")
			PluginInstallFrame.Desc1:SetText("You have completed the installation process.")
			PluginInstallFrame.Desc2:SetText("Please click the button below in order to finalize the process and automatically reload your UI.")
			PluginInstallFrame.Option1:Show()
			PluginInstallFrame.Option1:SetScript("OnClick", InstallComplete)
			PluginInstallFrame.Option1:SetText("Finished")
		end,
	},
	StepTitles = {
		[1] = "Welcome",
		[2] = "Layouts",
		[3] = "Details! Installation",
		[4] = "Installation Complete",
	},
	StepTitlesColor = {1, 1, 1},
	StepTitlesColorSelected = {0, 179/255, 1},
	StepTitleWidth = 200,
	StepTitleButtonWidth = 180,
	StepTitleTextJustification = "RIGHT",
}

--This function holds the options table which will be inserted into the ElvUI config
local function InsertOptions()
	E.Options.args.MyPluginName = {
		order = 100,
		type = "group",
		name = format("|cff4beb2c%s|r", MyPluginName),
		args = {
			header1 = {
				order = 1,
				type = "header",
				name = MyPluginName,
			},
			description1 = {
				order = 2,
				type = "description",
				name = format("%s is a layout for ElvUI.", MyPluginName),
			},
			spacer1 = {
				order = 3,
				type = "description",
				name = "\n\n\n",
			},
			header2 = {
				order = 4,
				type = "header",
				name = "Installation",
			},
			description2 = {
				order = 5,
				type = "description",
				name = "The installation guide should pop up automatically after you have completed the ElvUI installation. If you wish to re-run the installation process for this layout then please click the button below.",
			},
			spacer2 = {
				order = 6,
				type = "description",
				name = "",
			},
			install = {
				order = 7,
				type = "execute",
				name = "Install",
				desc = "Run the installation process.",
				func = function() E:GetModule("PluginInstaller"):Queue(InstallerData); E:ToggleOptionsUI(); end,
			},
		},
	}
end

--Create a unique table for our plugin
P[MyPluginName] = {}

--This function will handle initialization of the addon
function mod:Initialize()
	--Initiate installation process if ElvUI install is complete and our plugin install has not yet been run
	if E.private.install_complete and E.db[MyPluginName].install_version == nil then
		E:GetModule("PluginInstaller"):Queue(InstallerData)
	end
	
	--Insert our options table when ElvUI config is loaded
	EP:RegisterPlugin(addon, InsertOptions)
end

--Register module with callback so it gets initialized when ready
E:RegisterModule(mod:GetName())