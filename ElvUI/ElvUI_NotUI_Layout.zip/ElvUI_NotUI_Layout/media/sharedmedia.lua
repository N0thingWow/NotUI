local LSM = LibStub('LibSharedMedia-3.0')

if LSM == nil then return end

LSM:Register('font', 'NotUI Font light', [[Interface\AddOns\ElvUI_NotUI_Enhanced\media\fonts\NotUI Font light.ttf]])
LSM:Register('font', 'NotUI Font Heavy', [[Interface\AddOns\ElvUI_NotUI_Enhanced\media\fonts\NotUI Font Heavy.ttf]])